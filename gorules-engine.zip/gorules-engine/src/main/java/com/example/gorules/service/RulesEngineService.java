package com.example.gorules.service;

import com.example.gorules.model.RulesRequest;
import com.example.gorules.model.RulesResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.gorules.zen_engine.ZenEngine;
import io.gorules.zen_engine.JsonBuffer;
import io.gorules.zen_engine.ZenDecisionLoaderCallback;
import io.gorules.zen_engine.ZenEngineResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class RulesEngineService {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private static final String DECISION_KEY = "uploaded-rules";

    public RulesResponse executeRules(MultipartFile rulesFile, RulesRequest request) throws Exception {
        long startTime = System.currentTimeMillis();

        try {
            // Read rules JSON from file
            String rulesJson = new String(rulesFile.getBytes());

            // Parse and execute
            return executeRulesInline(rulesJson, request);

        } catch (Exception e) {
            log.error("Error executing rules", e);
            throw new RuntimeException("Failed to execute rules: " + e.getMessage(), e);
        }
    }

    public RulesResponse executeRulesInline(String rulesJson, RulesRequest request) throws Exception {
        long startTime = System.currentTimeMillis();

        try {
            // Create a loader callback that returns the rules JSON
            ZenDecisionLoaderCallback loaderCallback = (key) -> {
                return CompletableFuture.completedFuture(new JsonBuffer(rulesJson));
            };

            // Create ZenEngine instance with the loader
            ZenEngine engine = new ZenEngine(loaderCallback, null);

            // Prepare input data
            String inputJson = objectMapper.writeValueAsString(request.getData());
            JsonBuffer inputBuffer = new JsonBuffer(inputJson);

            // Execute the decision
            CompletableFuture<ZenEngineResponse> futureResponse =
                    engine.evaluate(DECISION_KEY, inputBuffer, null);

            ZenEngineResponse response = futureResponse.join();

            // Parse the result
            String resultJson = response.result().toString();
            Map<String, Object> result = objectMapper.readValue(resultJson, Map.class);

            long executionTime = System.currentTimeMillis() - startTime;

            log.info("Rules executed successfully in {}ms", executionTime);

            return RulesResponse.builder()
                    .success(true)
                    .result(result)
                    .executionTimeMs(executionTime)
                    .build();

        } catch (Exception e) {
            log.error("Error executing rules", e);
            long executionTime = System.currentTimeMillis() - startTime;

            return RulesResponse.builder()
                    .success(false)
                    .error(e.getMessage())
                    .executionTimeMs(executionTime)
                    .build();
        }
    }
}