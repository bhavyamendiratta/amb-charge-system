package com.example.gorules.controller;

import com.example.gorules.model.RulesRequest;
import com.example.gorules.model.RulesResponse;
import com.example.gorules.service.RulesEngineService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@RequestMapping("/api/rules")
@RequiredArgsConstructor
public class RulesEngineController {

    private final RulesEngineService rulesEngineService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Execute rules with JSON file upload and request data
     * Use form-data with:
     * - rulesFile: file
     * - data: JSON string
     */
    @PostMapping("/execute")
    public ResponseEntity<RulesResponse> executeRules(
            @RequestParam("rulesFile") MultipartFile rulesFile,
            @RequestParam("data") String dataJson) {
        try {
            // Parse the data JSON string
            Map<String, Object> data = objectMapper.readValue(dataJson, Map.class);

            RulesRequest request = RulesRequest.builder()
                    .data(data)
                    .build();

            RulesResponse response = rulesEngineService.executeRules(rulesFile, request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(RulesResponse.builder()
                            .success(false)
                            .error(e.getMessage())
                            .build());
        }
    }

    /**
     * Execute rules with JSON content in request body
     * Send both rules and data in the same JSON payload
     */
    @PostMapping("/execute-inline")
    public ResponseEntity<RulesResponse> executeRulesInline(
            @RequestBody Map<String, Object> requestBody) {
        try {
            String rulesJson = (String) requestBody.get("rules");
            @SuppressWarnings("unchecked")
            Map<String, Object> inputData = (Map<String, Object>) requestBody.get("data");

            if (rulesJson == null || inputData == null) {
                return ResponseEntity.badRequest()
                        .body(RulesResponse.builder()
                                .success(false)
                                .error("Both 'rules' and 'data' fields are required")
                                .build());
            }

            RulesRequest request = RulesRequest.builder()
                    .data(inputData)
                    .build();

            RulesResponse response = rulesEngineService.executeRulesInline(rulesJson, request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(RulesResponse.builder()
                            .success(false)
                            .error(e.getMessage())
                            .build());
        }
    }

    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status", "UP",
                "service", "GoRules Engine",
                "version", "1.0.0"
        ));
    }
}