curl -X POST http://localhost:8080/api/amb/check \
-H "Content-Type: application/json" \
-d '{
"checkDay": 25,
"minBalance": 10000,
"accounts": [
{
"accountId": "ACC001",
"accountName": "Rajesh Kumar",
"currentMonth": 3,
"dailyBalances": [
{"day": 1, "balance": 5000},
{"day": 2, "balance": 5000},
{"day": 3, "balance": 5000},
{"day": 4, "balance": 5000},
{"day": 5, "balance": 5000},
{"day": 6, "balance": 5000},
{"day": 7, "balance": 5000},
{"day": 8, "balance": 5000},
{"day": 9, "balance": 5000},
{"day": 10, "balance": 5000},
{"day": 11, "balance": 5000},
{"day": 12, "balance": 5000},
{"day": 13, "balance": 5000},
{"day": 14, "balance": 5000},
{"day": 15, "balance": 5000},
{"day": 16, "balance": 5000},
{"day": 17, "balance": 5000},
{"day": 18, "balance": 5000},
{"day": 19, "balance": 5000},
{"day": 20, "balance": 5000},
{"day": 21, "balance": 5000},
{"day": 22, "balance": 5000},
{"day": 23, "balance": 5000},
{"day": 24, "balance": 5000},
{"day": 25, "balance": 5000}
]
}
]
}'


curl -X POST http://localhost:8080/api/amb/check \
-H "Content-Type: application/json" \
-d '{
"checkDay": 25,
"minBalance": 10000,
"accounts": [
{
"accountId": "ACC002",
"accountName": "Priya Sharma",
"currentMonth": 3,
"dailyBalances": [
{"day": 1, "balance": 15000},
{"day": 2, "balance": 15000},
{"day": 3, "balance": 15000},
{"day": 4, "balance": 15000},
{"day": 5, "balance": 15000},
{"day": 6, "balance": 15000},
{"day": 7, "balance": 15000},
{"day": 8, "balance": 15000},
{"day": 9, "balance": 15000},
{"day": 10, "balance": 15000},
{"day": 11, "balance": 15000},
{"day": 12, "balance": 15000},
{"day": 13, "balance": 15000},
{"day": 14, "balance": 15000},
{"day": 15, "balance": 15000},
{"day": 16, "balance": 15000},
{"day": 17, "balance": 15000},
{"day": 18, "balance": 15000},
{"day": 19, "balance": 15000},
{"day": 20, "balance": 15000},
{"day": 21, "balance": 15000},
{"day": 22, "balance": 15000},
{"day": 23, "balance": 15000},
{"day": 24, "balance": 15000},
{"day": 25, "balance": 15000}
]
}
]
}'


curl -X POST http://localhost:8080/api/amb/check \
-H "Content-Type: application/json" \
-d '{
"checkDay": 25,
"minBalance": 10000,
"accounts": [
{
"accountId": "ACC101",
"accountName": "Sunita Verma",
"currentMonth": 5,
"dailyBalances": [
{"day": 1, "balance": 4000},
{"day": 2, "balance": 4000},
{"day": 3, "balance": 4000},
{"day": 4, "balance": 4000},
{"day": 5, "balance": 4000},
{"day": 6, "balance": 4000},
{"day": 7, "balance": 4000},
{"day": 8, "balance": 4000},
{"day": 9, "balance": 4000},
{"day": 10, "balance": 4000},
{"day": 11, "balance": 4000},
{"day": 12, "balance": 4000},
{"day": 13, "balance": 4000},
{"day": 14, "balance": 4000},
{"day": 15, "balance": 4000},
{"day": 16, "balance": 4000},
{"day": 17, "balance": 4000},
{"day": 18, "balance": 4000},
{"day": 19, "balance": 4000},
{"day": 20, "balance": 4000},
{"day": 21, "balance": 4000},
{"day": 22, "balance": 4000},
{"day": 23, "balance": 4000},
{"day": 24, "balance": 4000},
{"day": 25, "balance": 4000}
]
},
{
"accountId": "ACC102",
"accountName": "Vikram Singh",
"currentMonth": 5,
"dailyBalances": [
{"day": 1, "balance": 12000},
{"day": 2, "balance": 12000},
{"day": 3, "balance": 12000},
{"day": 4, "balance": 12000},
{"day": 5, "balance": 12000},
{"day": 6, "balance": 12000},
{"day": 7, "balance": 12000},
{"day": 8, "balance": 12000},
{"day": 9, "balance": 12000},
{"day": 10, "balance": 12000},
{"day": 11, "balance": 12000},
{"day": 12, "balance": 12000},
{"day": 13, "balance": 12000},
{"day": 14, "balance": 12000},
{"day": 15, "balance": 12000},
{"day": 16, "balance": 12000},
{"day": 17, "balance": 12000},
{"day": 18, "balance": 12000},
{"day": 19, "balance": 12000},
{"day": 20, "balance": 12000},
{"day": 21, "balance": 12000},
{"day": 22, "balance": 12000},
{"day": 23, "balance": 12000},
{"day": 24, "balance": 12000},
{"day": 25, "balance": 12000}
]
},
{
"accountId": "ACC103",
"accountName": "Meera Reddy",
"currentMonth": 5,
"dailyBalances": [
{"day": 1, "balance": 7500},
{"day": 2, "balance": 7500},
{"day": 3, "balance": 7500},
{"day": 4, "balance": 7500},
{"day": 5, "balance": 7500},
{"day": 6, "balance": 7500},
{"day": 7, "balance": 7500},
{"day": 8, "balance": 7500},
{"day": 9, "balance": 7500},
{"day": 10, "balance": 7500},
{"day": 11, "balance": 7500},
{"day": 12, "balance": 7500},
{"day": 13, "balance": 7500},
{"day": 14, "balance": 7500},
{"day": 15, "balance": 7500},
{"day": 16, "balance": 7500},
{"day": 17, "balance": 7500},
{"day": 18, "balance": 7500},
{"day": 19, "balance": 7500},
{"day": 20, "balance": 7500},
{"day": 21, "balance": 7500},
{"day": 22, "balance": 7500},
{"day": 23, "balance": 7500},
{"day": 24, "balance": 7500},
{"day": 25, "balance": 7500}
]
}
]
}'