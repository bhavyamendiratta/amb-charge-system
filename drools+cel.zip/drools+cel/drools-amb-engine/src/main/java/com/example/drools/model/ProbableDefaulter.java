package com.example.drools.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProbableDefaulter {
    private String accountId;
    private int month;
    private double amb;
    private boolean smsSent;
    private String reason;
}