package com.example.drools.controller;

import com.example.drools.model.AMBRequest;
import com.example.drools.model.AMBResponse;
import com.example.drools.service.AMBService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/amb")
@RequiredArgsConstructor
public class AMBController {

    private final AMBService ambService;

    /**
     * Process AMB defaulter check
     * Day 25: Check for probable defaulters
     * Day 3: Check for actual defaulters and apply charges
     */
    @PostMapping("/check")
    public ResponseEntity<AMBResponse> checkAMB(@RequestBody AMBRequest request) {
        try {
            AMBResponse response = ambService.processAMBCheck(request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(AMBResponse.builder()
                            .success(false)
                            .message("Error: " + e.getMessage())
                            .build());
        }
    }

    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status", "UP",
                "service", "AMB Defaulter Detection System",
                "version", "1.0.0"
        ));
    }
}