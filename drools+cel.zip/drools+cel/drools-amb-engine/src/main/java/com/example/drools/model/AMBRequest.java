package com.example.drools.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AMBRequest {
    private int checkDay;  // 25 or 3
    private double minBalance;  // e.g., 10000
    private List<AccountData> accounts;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AccountData {
        private String accountId;
        private String accountName;
        private int currentMonth;
        private List<DailyBalance> dailyBalances;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DailyBalance {
        private int day;
        private double balance;
    }
}