package com.example.drools.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Charge {
    private String accountId;
    private int month1;
    private int month2;
    private double shortfall1;
    private double shortfall2;
    private double totalShortfall;
    private double baseCharge;
    private double gstAmount;
    private double totalCharge;
    private int chargedInMonth;
    private String reason;
}