package com.example.drools.service;

import com.example.drools.model.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class AMBService {

    private final KieContainer kieContainer;

    public AMBResponse processAMBCheck(AMBRequest request) {
        long startTime = System.currentTimeMillis();
        KieSession kieSession = kieContainer.newKieSession();

        try {
            // Initialize lists to collect results
            List<ProbableDefaulter> probableDefaulters = new ArrayList<>();
            List<ActualDefaulter> actualDefaulters = new ArrayList<>();
            List<Charge> charges = new ArrayList<>();

            // Set global variables
            kieSession.setGlobal("probableDefaultersList", probableDefaulters);
            kieSession.setGlobal("actualDefaultersList", actualDefaulters);
            kieSession.setGlobal("chargesList", charges);

            // Create and insert execution context
            ExecutionContext context = ExecutionContext.builder()
                    .checkDay(request.getCheckDay())
                    .minBalance(request.getMinBalance())
                    .build();
            kieSession.insert(context);

            // Process each account
            for (AMBRequest.AccountData accountData : request.getAccounts()) {
                Account account = convertToAccount(accountData);
                kieSession.insert(account);
            }

            // Fire all rules
            int rulesFired = kieSession.fireAllRules();

            // Calculate summary
            double totalCharges = charges.stream()
                    .mapToDouble(Charge::getTotalCharge)
                    .sum();

            AMBResponse.Summary summary = AMBResponse.Summary.builder()
                    .totalAccountsProcessed(request.getAccounts().size())
                    .probableDefaultersCount(probableDefaulters.size())
                    .actualDefaultersCount(actualDefaulters.size())
                    .chargesAppliedCount(charges.size())
                    .totalChargesAmount(totalCharges)
                    .build();

            long executionTime = System.currentTimeMillis() - startTime;

            log.info("AMB Check completed. Rules fired: {}, Time: {}ms", rulesFired, executionTime);

            return AMBResponse.builder()
                    .success(true)
                    .message("AMB check completed successfully")
                    .rulesFired(rulesFired)
                    .executionTimeMs(executionTime)
                    .probableDefaulters(probableDefaulters)
                    .actualDefaulters(actualDefaulters)
                    .charges(charges)
                    .summary(summary)
                    .build();

        } catch (Exception e) {
            log.error("Error processing AMB check", e);
            long executionTime = System.currentTimeMillis() - startTime;

            return AMBResponse.builder()
                    .success(false)
                    .message("Error: " + e.getMessage())
                    .executionTimeMs(executionTime)
                    .build();
        } finally {
            kieSession.dispose();
        }
    }

    private Account convertToAccount(AMBRequest.AccountData accountData) {
        Account account = Account.builder()
                .accountId(accountData.getAccountId())
                .accountName(accountData.getAccountName())
                .currentMonth(accountData.getCurrentMonth())
                .build();

        account.initializeDailyBalances();

        // Set daily balances
        if (accountData.getDailyBalances() != null) {
            for (AMBRequest.DailyBalance db : accountData.getDailyBalances()) {
                account.setDailyBalance(db.getDay(), db.getBalance());
            }
        }

        return account;
    }
}