package com.example.drools.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Account {
    private String accountId;
    private String accountName;
    private int currentMonth;

    // Daily balances: key = day (1-30), value = balance
    private Map<Integer, Double> dailyBalances;

    /**
     * Calculate Average Monthly Balance for a given period
     * @param startDay Starting day (inclusive)
     * @param endDay Ending day (inclusive)
     * @return Average balance for the period
     */
    public double calculateAMB(int startDay, int endDay) {
        if (dailyBalances == null || dailyBalances.isEmpty()) {
            return 0.0;
        }

        double sum = 0.0;
        int daysCount = 0;

        for (int day = startDay; day <= endDay; day++) {
            Double balance = dailyBalances.get(day);
            if (balance != null) {
                sum += balance;
                daysCount++;
            }
        }

        return daysCount > 0 ? sum / daysCount : 0.0;
    }

    /**
     * Helper method to initialize daily balances
     */
    public void initializeDailyBalances() {
        if (this.dailyBalances == null) {
            this.dailyBalances = new HashMap<>();
        }
    }

    /**
     * Set balance for a specific day
     */
    public void setDailyBalance(int day, double balance) {
        if (this.dailyBalances == null) {
            initializeDailyBalances();
        }
        this.dailyBalances.put(day, balance);
    }

    /**
     * Set same balance for a range of days
     */
    public void setBalanceForRange(int startDay, int endDay, double balance) {
        if (this.dailyBalances == null) {
            initializeDailyBalances();
        }
        for (int day = startDay; day <= endDay; day++) {
            this.dailyBalances.put(day, balance);
        }
    }
}