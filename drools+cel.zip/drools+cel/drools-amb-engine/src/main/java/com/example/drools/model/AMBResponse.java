package com.example.drools.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AMBResponse {
    private boolean success;
    private String message;
    private int rulesFired;
    private long executionTimeMs;

    // Results
    private List<ProbableDefaulter> probableDefaulters;
    private List<ActualDefaulter> actualDefaulters;
    private List<Charge> charges;

    // Summary
    private Summary summary;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Summary {
        private int totalAccountsProcessed;
        private int probableDefaultersCount;
        private int actualDefaultersCount;
        private int chargesAppliedCount;
        private double totalChargesAmount;
    }
}