package com.example.drools.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExecutionContext {
    private int checkDay;  // 25 for probable defaulter check, 3 for actual defaulter check
    private double minBalance;  // Minimum required AMB (e.g., 10000)
}