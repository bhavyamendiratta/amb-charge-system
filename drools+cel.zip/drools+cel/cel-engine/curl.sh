#!/bin/bash

# ========================================
# CEL Rules Engine - Complete CURL Test Suite
# ========================================

BASE_URL="http://localhost:8090"

echo "=========================================="
echo "CEL Rules Engine - Test Suite"
echo "=========================================="
echo ""

# ========================================
# 1. HEALTH CHECK
# ========================================
echo "1. Health Check"
echo "----------------------------------------"
curl -X GET ${BASE_URL}/api/cel/health
echo -e "\n\n"

# ========================================
# 2. SIMPLE EXPRESSIONS
# ========================================
echo "2. Simple Boolean Expression"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/execute \
  -H "Content-Type: application/json" \
  -d '{
    "expression": "age >= 21 && income > 50000",
    "variables": {
      "age": 30,
      "income": 75000
    }
  }'
echo -e "\n\n"

echo "3. Arithmetic Expression"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/execute \
  -H "Content-Type: application/json" \
  -d '{
    "expression": "(salary * 12) + bonus - tax",
    "variables": {
      "salary": 5000,
      "bonus": 10000,
      "tax": 8000
    }
  }'
echo -e "\n\n"

echo "4. String Operations"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/execute \
  -H "Content-Type: application/json" \
  -d '{
    "expression": "\"Hello, \" + name + \"!\"",
    "variables": {
      "name": "Bhavya"
    }
  }'
echo -e "\n\n"

echo "5. Ternary Operator"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/execute \
  -H "Content-Type: application/json" \
  -d '{
    "expression": "age >= 18 ? \"adult\" : \"minor\"",
    "variables": {
      "age": 25
    }
  }'
echo -e "\n\n"

# ========================================
# 6. STORE RULES
# ========================================
echo "6. Store Loan Eligibility Rule"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules \
  -H "Content-Type: application/json" \
  -d '{
    "fileName": "loan-eligibility.cel",
    "expression": "age >= 21 && age <= 65 && income >= 25000 && creditScore >= 650 && employmentType == \"salaried\" && existingLoans <= 3",
    "description": "Loan eligibility check"
  }'
echo -e "\n\n"

echo "7. Store Discount Rule"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules \
  -H "Content-Type: application/json" \
  -d '{
    "fileName": "discount.cel",
    "expression": "income >= 100000 && tier == \"gold\" ? 20 : income >= 50000 && tier == \"gold\" ? 15 : income >= 50000 && tier == \"silver\" ? 10 : income >= 25000 && tier == \"bronze\" ? 5 : 0",
    "description": "Discount calculation"
  }'
echo -e "\n\n"

echo "8. Store Fraud Detection Rule"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules \
  -H "Content-Type: application/json" \
  -d '{
    "fileName": "fraud-detection.cel",
    "expression": "amount > 100000 && time >= 22 && location != homeLocation ? \"HIGH_RISK\" : amount > 50000 && dailyCount > 5 ? \"MEDIUM_RISK\" : amount > 10000 ? \"LOW_RISK\" : \"NORMAL\"",
    "description": "Fraud risk assessment"
  }'
echo -e "\n\n"

echo "9. Store Credit Score Rule"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules \
  -H "Content-Type: application/json" \
  -d '{
    "fileName": "credit-score.cel",
    "expression": "creditScore >= 750 ? \"Excellent\" : creditScore >= 700 ? \"Good\" : creditScore >= 650 ? \"Fair\" : \"Poor\"",
    "description": "Credit score rating"
  }'
echo -e "\n\n"

echo "10. Store Age Verification Rule"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules \
  -H "Content-Type: application/json" \
  -d '{
    "fileName": "age-check.cel",
    "expression": "age >= 21",
    "description": "Simple age verification"
  }'
echo -e "\n\n"

# ========================================
# 11. LIST ALL RULES
# ========================================
echo "11. Get All Stored Rules"
echo "----------------------------------------"
curl -X GET ${BASE_URL}/api/cel/rules
echo -e "\n\n"

# ========================================
# 12. EXECUTE LOAN ELIGIBILITY RULES
# ========================================
echo "12. Execute Loan Eligibility - APPROVED"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "loan-eligibility.cel",
    "variables": {
      "age": 30,
      "income": 50000,
      "creditScore": 720,
      "employmentType": "salaried",
      "existingLoans": 2
    }
  }'
echo -e "\n\n"

echo "13. Execute Loan Eligibility - REJECTED (Too Young)"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "loan-eligibility.cel",
    "variables": {
      "age": 18,
      "income": 50000,
      "creditScore": 720,
      "employmentType": "salaried",
      "existingLoans": 2
    }
  }'
echo -e "\n\n"

echo "14. Execute Loan Eligibility - REJECTED (Low Credit)"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "loan-eligibility.cel",
    "variables": {
      "age": 30,
      "income": 50000,
      "creditScore": 600,
      "employmentType": "salaried",
      "existingLoans": 2
    }
  }'
echo -e "\n\n"

echo "15. Execute Loan Eligibility - REJECTED (Too Many Loans)"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "loan-eligibility.cel",
    "variables": {
      "age": 30,
      "income": 50000,
      "creditScore": 720,
      "employmentType": "salaried",
      "existingLoans": 5
    }
  }'
echo -e "\n\n"

# ========================================
# 16. EXECUTE DISCOUNT RULES
# ========================================
echo "16. Execute Discount - Gold Tier High Income (20%)"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "discount.cel",
    "variables": {
      "income": 150000,
      "tier": "gold"
    }
  }'
echo -e "\n\n"

echo "17. Execute Discount - Gold Tier Medium Income (15%)"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "discount.cel",
    "variables": {
      "income": 60000,
      "tier": "gold"
    }
  }'
echo -e "\n\n"

echo "18. Execute Discount - Silver Tier (10%)"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "discount.cel",
    "variables": {
      "income": 60000,
      "tier": "silver"
    }
  }'
echo -e "\n\n"

echo "19. Execute Discount - Bronze Tier (5%)"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "discount.cel",
    "variables": {
      "income": 30000,
      "tier": "bronze"
    }
  }'
echo -e "\n\n"

echo "20. Execute Discount - No Discount (0%)"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "discount.cel",
    "variables": {
      "income": 20000,
      "tier": "bronze"
    }
  }'
echo -e "\n\n"

# ========================================
# 21. EXECUTE FRAUD DETECTION RULES
# ========================================
echo "21. Execute Fraud Detection - HIGH RISK"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "fraud-detection.cel",
    "variables": {
      "amount": 150000,
      "time": 23,
      "location": "Mumbai",
      "homeLocation": "Delhi",
      "dailyCount": 3
    }
  }'
echo -e "\n\n"

echo "22. Execute Fraud Detection - MEDIUM RISK"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "fraud-detection.cel",
    "variables": {
      "amount": 60000,
      "time": 14,
      "location": "Delhi",
      "homeLocation": "Delhi",
      "dailyCount": 6
    }
  }'
echo -e "\n\n"

echo "23. Execute Fraud Detection - LOW RISK"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "fraud-detection.cel",
    "variables": {
      "amount": 15000,
      "time": 14,
      "location": "Delhi",
      "homeLocation": "Delhi",
      "dailyCount": 3
    }
  }'
echo -e "\n\n"

echo "24. Execute Fraud Detection - NORMAL"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "fraud-detection.cel",
    "variables": {
      "amount": 5000,
      "time": 14,
      "location": "Delhi",
      "homeLocation": "Delhi",
      "dailyCount": 2
    }
  }'
echo -e "\n\n"

# ========================================
# 25. EXECUTE CREDIT SCORE RULES
# ========================================
echo "25. Execute Credit Score - Excellent"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "credit-score.cel",
    "variables": {
      "creditScore": 780
    }
  }'
echo -e "\n\n"

echo "26. Execute Credit Score - Good"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "credit-score.cel",
    "variables": {
      "creditScore": 720
    }
  }'
echo -e "\n\n"

echo "27. Execute Credit Score - Fair"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "credit-score.cel",
    "variables": {
      "creditScore": 670
    }
  }'
echo -e "\n\n"

echo "28. Execute Credit Score - Poor"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "credit-score.cel",
    "variables": {
      "creditScore": 620
    }
  }'
echo -e "\n\n"

# ========================================
# 29. COMPLEX EXPRESSIONS
# ========================================
echo "29. Complex Multi-Condition Expression"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/execute \
  -H "Content-Type: application/json" \
  -d '{
    "expression": "(age >= 21 && age <= 65) && (income >= 25000) && (creditScore >= 650) && (employmentType == \"salaried\" || employmentType == \"self-employed\")",
    "variables": {
      "age": 35,
      "income": 75000,
      "creditScore": 700,
      "employmentType": "self-employed"
    }
  }'
echo -e "\n\n"

echo "30. String Concatenation Expression"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/execute \
  -H "Content-Type: application/json" \
  -d '{
    "expression": "firstName + \" \" + lastName + \" is \" + string(age) + \" years old\"",
    "variables": {
      "firstName": "Bhavya",
      "lastName": "Patel",
      "age": 30
    }
  }'
echo -e "\n\n"

echo "31. Mathematical Expression"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/execute \
  -H "Content-Type: application/json" \
  -d '{
    "expression": "price * quantity * (1 - discount / 100) * (1 + tax / 100)",
    "variables": {
      "price": 100,
      "quantity": 5,
      "discount": 10,
      "tax": 18
    }
  }'
echo -e "\n\n"

# ========================================
# 32. GET SPECIFIC RULES
# ========================================
echo "32. Get Loan Eligibility Rule Details"
echo "----------------------------------------"
curl -X GET ${BASE_URL}/api/cel/rules/loan-eligibility.cel
echo -e "\n\n"

echo "33. Get Discount Rule Details"
echo "----------------------------------------"
curl -X GET ${BASE_URL}/api/cel/rules/discount.cel
echo -e "\n\n"

# ========================================
# 34. ERROR HANDLING TESTS
# ========================================
echo "34. Test Error - Undeclared Variable"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/execute \
  -H "Content-Type: application/json" \
  -d '{
    "expression": "unknownVar > 100",
    "variables": {
      "age": 30
    }
  }'
echo -e "\n\n"

echo "35. Test Error - Type Mismatch"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/execute \
  -H "Content-Type: application/json" \
  -d '{
    "expression": "age + name",
    "variables": {
      "age": 30,
      "name": "John"
    }
  }'
echo -e "\n\n"

echo "36. Test Error - Rule Not Found"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/rules/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ruleFileName": "non-existent-rule.cel",
    "variables": {
      "age": 30
    }
  }'
echo -e "\n\n"

# ========================================
# 37. EDGE CASES
# ========================================
echo "37. Edge Case - Zero Values"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/execute \
  -H "Content-Type: application/json" \
  -d '{
    "expression": "value == 0",
    "variables": {
      "value": 0
    }
  }'
echo -e "\n\n"

echo "38. Edge Case - Negative Numbers"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/execute \
  -H "Content-Type: application/json" \
  -d '{
    "expression": "balance < 0 ? \"Overdrawn\" : \"OK\"",
    "variables": {
      "balance": -500
    }
  }'
echo -e "\n\n"

echo "39. Edge Case - Empty String"
echo "----------------------------------------"
curl -X POST ${BASE_URL}/api/cel/execute \
  -H "Content-Type: application/json" \
  -d '{
    "expression": "name != \"\" && name.size() > 0",
    "variables": {
      "name": ""
    }
  }'
echo -e "\n\n"

# ========================================
# 40. DELETE RULES (Optional - Cleanup)
# ========================================
echo "40. Delete Age Check Rule"
echo "----------------------------------------"
curl -X DELETE ${BASE_URL}/api/cel/rules/age-check.cel
echo -e "\n\n"

# ========================================
# SUMMARY
# ========================================
echo "=========================================="
echo "Test Suite Completed!"
echo "=========================================="
echo ""
echo "Summary:"
echo "- Total Tests: 40"
echo "- Health Check: ✓"
echo "- Simple Expressions: ✓"
echo "- Rule Storage: ✓"
echo "- Rule Execution: ✓"
echo "- Error Handling: ✓"
echo "- Edge Cases: ✓"
echo ""
echo "=========================================="