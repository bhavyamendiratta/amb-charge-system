package com.example.cel.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CelRequest {
    private String expression;  // CEL expression to evaluate
    private Map<String, Object> variables;  // Variables/context for the expression
}