package com.example.cel.service;

import com.example.cel.model.CelRequest;
import com.example.cel.model.CelResponse;
import com.example.cel.model.CelRule;
import dev.cel.common.CelAbstractSyntaxTree;
import dev.cel.common.CelValidationException;
import dev.cel.common.types.SimpleType;
import dev.cel.compiler.CelCompiler;
import dev.cel.compiler.CelCompilerFactory;
import dev.cel.runtime.CelEvaluationException;
import dev.cel.runtime.CelRuntime;
import dev.cel.runtime.CelRuntimeFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@Slf4j
public class CelEngineService {

    // In-memory storage for CEL rules (in production, use a database)
    private final Map<String, CelRule> rulesStore = new ConcurrentHashMap<>();

    // CEL Runtime is thread-safe and should be reused
    private final CelRuntime celRuntime;

    public CelEngineService() {
        this.celRuntime = CelRuntimeFactory.standardCelRuntimeBuilder().build();
    }

    /**
     * Execute a CEL expression directly
     */
    public CelResponse executeExpression(CelRequest request) {
        long startTime = System.currentTimeMillis();

        try {
            log.info("Executing CEL expression: {}", request.getExpression());

            // Build compiler with variable declarations
            CelCompiler celCompiler = buildCompiler(request.getVariables());

            // Compile the expression
            CelAbstractSyntaxTree ast = celCompiler.compile(request.getExpression()).getAst();

            // Create program and evaluate
            CelRuntime.Program program = celRuntime.createProgram(ast);
            Object result = program.eval(request.getVariables());

            long executionTime = System.currentTimeMillis() - startTime;

            log.info("CEL expression executed successfully. Result: {}, Time: {}ms",
                    result, executionTime);

            return CelResponse.builder()
                    .success(true)
                    .result(result)
                    .resultType(result != null ? result.getClass().getSimpleName() : "null")
                    .expression(request.getExpression())
                    .executionTimeMs(executionTime)
                    .build();

        } catch (CelValidationException e) {
            log.error("CEL validation error", e);
            long executionTime = System.currentTimeMillis() - startTime;

            return CelResponse.builder()
                    .success(false)
                    .error("Validation error: " + e.getMessage())
                    .expression(request.getExpression())
                    .executionTimeMs(executionTime)
                    .build();
        } catch (CelEvaluationException e) {
            log.error("CEL evaluation error", e);
            long executionTime = System.currentTimeMillis() - startTime;

            return CelResponse.builder()
                    .success(false)
                    .error("Evaluation error: " + e.getMessage())
                    .expression(request.getExpression())
                    .executionTimeMs(executionTime)
                    .build();
        } catch (Exception e) {
            log.error("Error executing CEL expression", e);
            long executionTime = System.currentTimeMillis() - startTime;

            return CelResponse.builder()
                    .success(false)
                    .error(e.getMessage())
                    .expression(request.getExpression())
                    .executionTimeMs(executionTime)
                    .build();
        }
    }

    /**
     * Store a CEL rule file
     */
    public void storeRule(String fileName, String expression, String description) {
        CelRule rule = CelRule.builder()
                .fileName(fileName)
                .expression(expression)
                .description(description)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        rulesStore.put(fileName, rule);
        log.info("Stored CEL rule: {}", fileName);
    }

    /**
     * Execute a stored CEL rule file
     */
    public CelResponse executeRuleFile(String fileName, Map<String, Object> variables) {
        long startTime = System.currentTimeMillis();

        try {
            CelRule rule = rulesStore.get(fileName);
            if (rule == null) {
                throw new IllegalArgumentException("Rule file not found: " + fileName);
            }

            log.info("Executing CEL rule file: {}", fileName);

            // Build compiler with variable declarations
            CelCompiler celCompiler = buildCompiler(variables);

            // Compile the expression
            CelAbstractSyntaxTree ast = celCompiler.compile(rule.getExpression()).getAst();

            // Create program and evaluate
            CelRuntime.Program program = celRuntime.createProgram(ast);
            Object result = program.eval(variables);

            long executionTime = System.currentTimeMillis() - startTime;

            log.info("CEL rule file executed successfully. Result: {}, Time: {}ms",
                    result, executionTime);

            return CelResponse.builder()
                    .success(true)
                    .result(result)
                    .resultType(result != null ? result.getClass().getSimpleName() : "null")
                    .expression(rule.getExpression())
                    .executionTimeMs(executionTime)
                    .build();

        } catch (CelValidationException e) {
            log.error("CEL validation error", e);
            long executionTime = System.currentTimeMillis() - startTime;

            return CelResponse.builder()
                    .success(false)
                    .error("Validation error: " + e.getMessage())
                    .executionTimeMs(executionTime)
                    .build();
        } catch (CelEvaluationException e) {
            log.error("CEL evaluation error", e);
            long executionTime = System.currentTimeMillis() - startTime;

            return CelResponse.builder()
                    .success(false)
                    .error("Evaluation error: " + e.getMessage())
                    .executionTimeMs(executionTime)
                    .build();
        } catch (Exception e) {
            log.error("Error executing CEL rule file", e);
            long executionTime = System.currentTimeMillis() - startTime;

            return CelResponse.builder()
                    .success(false)
                    .error(e.getMessage())
                    .executionTimeMs(executionTime)
                    .build();
        }
    }

    /**
     * Get a stored rule
     */
    public CelRule getRule(String fileName) {
        return rulesStore.get(fileName);
    }

    /**
     * Get all stored rules
     */
    public Map<String, CelRule> getAllRules() {
        return new HashMap<>(rulesStore);
    }

    /**
     * Delete a stored rule
     */
    public boolean deleteRule(String fileName) {
        CelRule removed = rulesStore.remove(fileName);
        if (removed != null) {
            log.info("Deleted CEL rule: {}", fileName);
            return true;
        }
        return false;
    }

    /**
     * Build CEL compiler with variable declarations from provided variables
     */
    private CelCompiler buildCompiler(Map<String, Object> variables) {
        // Use var to let Java infer the builder type
        var builder = CelCompilerFactory.standardCelCompilerBuilder();

        // Add variable declarations based on the provided variables
        if (variables != null) {
            for (Map.Entry<String, Object> entry : variables.entrySet()) {
                String varName = entry.getKey();
                Object value = entry.getValue();

                // Declare variable types
                if (value instanceof Boolean) {
                    builder.addVar(varName, SimpleType.BOOL);
                } else if (value instanceof Integer || value instanceof Long) {
                    builder.addVar(varName, SimpleType.INT);
                } else if (value instanceof Double || value instanceof Float) {
                    builder.addVar(varName, SimpleType.DOUBLE);
                } else if (value instanceof String) {
                    builder.addVar(varName, SimpleType.STRING);
                } else {
                    // Default to dynamic type
                    builder.addVar(varName, SimpleType.DYN);
                }
            }
        }

        return builder.build();
    }
}