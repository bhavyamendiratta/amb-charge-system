package com.example.cel.controller;

import com.example.cel.model.*;
import com.example.cel.service.CelEngineService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.charset.StandardCharsets;
import java.util.Map;

@RestController
@RequestMapping("/api/cel")
@RequiredArgsConstructor
public class CelController {

    private final CelEngineService celEngineService;

    /**
     * Execute a CEL expression directly
     * POST /api/cel/execute
     */
    @PostMapping("/execute")
    public ResponseEntity<CelResponse> executeExpression(@RequestBody CelRequest request) {
        try {
            CelResponse response = celEngineService.executeExpression(request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(CelResponse.builder()
                            .success(false)
                            .error(e.getMessage())
                            .build());
        }
    }

    /**
     * Upload and store a CEL rule file
     * POST /api/cel/rules/upload
     */
    @PostMapping("/rules/upload")
    public ResponseEntity<Map<String, String>> uploadRuleFile(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "description", required = false) String description) {
        try {
            String fileName = file.getOriginalFilename();
            String expression = new String(file.getBytes(), StandardCharsets.UTF_8);

            celEngineService.storeRule(fileName, expression, description);

            return ResponseEntity.ok(Map.of(
                    "status", "success",
                    "message", "Rule file uploaded successfully",
                    "fileName", fileName
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(Map.of(
                            "status", "error",
                            "message", e.getMessage()
                    ));
        }
    }

    /**
     * Store a CEL rule via JSON
     * POST /api/cel/rules
     */
    @PostMapping("/rules")
    public ResponseEntity<Map<String, String>> storeRule(@RequestBody Map<String, String> request) {
        try {
            String fileName = request.get("fileName");
            String expression = request.get("expression");
            String description = request.get("description");

            if (fileName == null || expression == null) {
                throw new IllegalArgumentException("fileName and expression are required");
            }

            celEngineService.storeRule(fileName, expression, description);

            return ResponseEntity.ok(Map.of(
                    "status", "success",
                    "message", "Rule stored successfully",
                    "fileName", fileName
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(Map.of(
                            "status", "error",
                            "message", e.getMessage()
                    ));
        }
    }

    /**
     * Execute a stored CEL rule file
     * POST /api/cel/rules/execute
     */
    @PostMapping("/rules/execute")
    public ResponseEntity<CelResponse> executeRuleFile(@RequestBody CelFileRequest request) {
        try {
            CelResponse response = celEngineService.executeRuleFile(
                    request.getRuleFileName(),
                    request.getVariables()
            );
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(CelResponse.builder()
                            .success(false)
                            .error(e.getMessage())
                            .build());
        }
    }

    /**
     * Get a stored rule
     * GET /api/cel/rules/{fileName}
     */
    @GetMapping("/rules/{fileName}")
    public ResponseEntity<?> getRule(@PathVariable String fileName) {
        CelRule rule = celEngineService.getRule(fileName);
        if (rule != null) {
            return ResponseEntity.ok(rule);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Get all stored rules
     * GET /api/cel/rules
     */
    @GetMapping("/rules")
    public ResponseEntity<Map<String, CelRule>> getAllRules() {
        return ResponseEntity.ok(celEngineService.getAllRules());
    }

    /**
     * Delete a stored rule
     * DELETE /api/cel/rules/{fileName}
     */
    @DeleteMapping("/rules/{fileName}")
    public ResponseEntity<Map<String, String>> deleteRule(@PathVariable String fileName) {
        boolean deleted = celEngineService.deleteRule(fileName);
        if (deleted) {
            return ResponseEntity.ok(Map.of(
                    "status", "success",
                    "message", "Rule deleted successfully",
                    "fileName", fileName
            ));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Health check endpoint
     * GET /api/cel/health
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status", "UP",
                "service", "CEL Rules Engine",
                "version", "1.0.0"
        ));
    }
}