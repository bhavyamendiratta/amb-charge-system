package com.example.cel.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CelFileRequest {
    private String ruleFileName;  // Name of the CEL rule file (e.g., "loan-rules.cel")
    private Map<String, Object> variables;  // Variables/context for the expression
}