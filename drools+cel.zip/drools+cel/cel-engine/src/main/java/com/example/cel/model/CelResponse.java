package com.example.cel.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CelResponse {
    private boolean success;
    private Object result;  // Result of the CEL expression evaluation
    private String resultType;  // Type of the result (boolean, string, number, etc.)
    private String error;
    private long executionTimeMs;
    private String expression;  // Echo back the expression
}