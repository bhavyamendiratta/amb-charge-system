package com.example.cel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CelEngineApplication {
    public static void main(String[] args) {
        SpringApplication.run(CelEngineApplication.class, args);
    }
}