curl -X POST http://localhost:8085/api/rules/execute \
-H "Content-Type: application/json" \
-d '{
"ruleType": "discount",
"data": {
"income": 5000,
"tier": "gold"
}
}'

curl -X POST http://localhost:8085/api/rules/execute \
-H "Content-Type: application/json" \
-d '{
"ruleType": "discount",
"data": {
"income": 3000,
"tier": "silver"
}
}'

curl -X POST http://localhost:8085/api/rules/execute \
-H "Content-Type: application/json" \
-d '{
"ruleType": "loan",
"data": {
"applicationId": "LOAN001",
"customerId": "CUST001",
"age": 35,
"income": 150000,
"creditScore": 780,
"employmentType": "salaried",
"existingLoans": 0,
"loanAmount": 5000000
}
}'

curl -X POST http://localhost:8085/api/rules/execute \
-H "Content-Type: application/json" \
-d '{
"ruleType": "loan",
"data": {
"applicationId": "LOAN002",
"customerId": "CUST002",
"age": 30,
"income": 60000,
"creditScore": 720,
"employmentType": "salaried",
"existingLoans": 1,
"loanAmount": 2000000
}
}'

curl -X POST http://localhost:8085/api/rules/execute \
-H "Content-Type: application/json" \
-d '{
"ruleType": "loan",
"data": {
"applicationId": "LOAN003",
"customerId": "CUST003",
"age": 40,
"income": 80000,
"creditScore": 750,
"employmentType": "self-employed",
"existingLoans": 2,
"loanAmount": 2000000
}
}'

curl -X POST http://localhost:8085/api/rules/execute \
-H "Content-Type: application/json" \
-d '{
"ruleType": "loan",
"data": {
"applicationId": "LOAN004",
"customerId": "CUST004",
"age": 18,
"income": 50000,
"creditScore": 700,
"employmentType": "salaried",
"existingLoans": 0,
"loanAmount": 1000000
}
}'

