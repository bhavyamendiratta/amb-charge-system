package com.example.drools.service;

import com.example.drools.model.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.Message;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class RulesEngineService {

    private final KieContainer kieContainer;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public RulesResponse executeRules(RulesRequest request) {
        long startTime = System.currentTimeMillis();
        KieSession kieSession = kieContainer.newKieSession();

        try {
            String ruleType = request.getRuleType();
            Object fact = null;

            switch (ruleType.toLowerCase()) {
                case "discount":
                    fact = createDiscountRequest(request.getData());
                    break;
                case "loan":
                    fact = createLoanApplication(request.getData());
                    break;
                case "customer":
                    fact = createCustomer(request.getData());
                    break;
                default:
                    throw new IllegalArgumentException("Unknown rule type: " + ruleType);
            }

            kieSession.insert(fact);
            int rulesFired = kieSession.fireAllRules();

            Map<String, Object> result = objectMapper.convertValue(fact, Map.class);

            long executionTime = System.currentTimeMillis() - startTime;
            log.info("Rules executed successfully. Rules fired: {}, Time: {}ms", rulesFired, executionTime);

            return RulesResponse.builder()
                    .success(true)
                    .result(result)
                    .rulesFired(rulesFired)
                    .executionTimeMs(executionTime)
                    .build();

        } catch (Exception e) {
            log.error("Error executing rules", e);
            long executionTime = System.currentTimeMillis() - startTime;

            return RulesResponse.builder()
                    .success(false)
                    .error(e.getMessage())
                    .executionTimeMs(executionTime)
                    .build();
        } finally {
            kieSession.dispose();
        }
    }

    public RulesResponse executeCustomRules(String drlContent, RulesRequest request) {
        long startTime = System.currentTimeMillis();

        try {
            KieServices kieServices = KieServices.Factory.get();
            KieFileSystem kieFileSystem = kieServices.newKieFileSystem();

            kieFileSystem.write("src/main/resources/custom-rules.drl", drlContent);

            KieBuilder kieBuilder = kieServices.newKieBuilder(kieFileSystem);
            kieBuilder.buildAll();

            if (kieBuilder.getResults().hasMessages(Message.Level.ERROR)) {
                String errors = kieBuilder.getResults().toString();
                throw new RuntimeException("DRL compilation errors: " + errors);
            }

            KieContainer customContainer = kieServices.newKieContainer(
                    kieBuilder.getKieModule().getReleaseId());
            KieSession kieSession = customContainer.newKieSession();

            try {
                Object fact = createFactFromData(request.getData());
                kieSession.insert(fact);
                int rulesFired = kieSession.fireAllRules();

                Map<String, Object> result = objectMapper.convertValue(fact, Map.class);

                long executionTime = System.currentTimeMillis() - startTime;

                return RulesResponse.builder()
                        .success(true)
                        .result(result)
                        .rulesFired(rulesFired)
                        .executionTimeMs(executionTime)
                        .build();

            } finally {
                kieSession.dispose();
            }

        } catch (Exception e) {
            log.error("Error executing custom rules", e);
            long executionTime = System.currentTimeMillis() - startTime;

            return RulesResponse.builder()
                    .success(false)
                    .error(e.getMessage())
                    .executionTimeMs(executionTime)
                    .build();
        }
    }

    private DiscountRequest createDiscountRequest(Map<String, Object> data) {
        return DiscountRequest.builder()
                .income(getDoubleValue(data, "income"))
                .tier((String) data.get("tier"))
                .build();
    }

    private LoanApplication createLoanApplication(Map<String, Object> data) {
        return LoanApplication.builder()
                .applicationId((String) data.get("applicationId"))
                .customerId((String) data.get("customerId"))
                .age(getIntValue(data, "age"))
                .income(getDoubleValue(data, "income"))
                .creditScore(getDoubleValue(data, "creditScore"))
                .employmentType((String) data.get("employmentType"))
                .existingLoans(getIntValue(data, "existingLoans"))
                .loanAmount(getDoubleValue(data, "loanAmount"))
                .build();
    }

    private Customer createCustomer(Map<String, Object> data) {
        return Customer.builder()
                .customerId((String) data.get("customerId"))
                .name((String) data.get("name"))
                .income(getDoubleValue(data, "income"))
                .tier((String) data.get("tier"))
                .age(getIntValue(data, "age"))
                .creditScore(getDoubleValue(data, "creditScore"))
                .build();
    }

    private Object createFactFromData(Map<String, Object> data) {
        // Generic fact creation - adjust based on your needs
        return objectMapper.convertValue(data, Customer.class);
    }

    private double getDoubleValue(Map<String, Object> data, String key) {
        Object value = data.get(key);
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        return 0.0;
    }

    private int getIntValue(Map<String, Object> data, String key) {
        Object value = data.get(key);
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return 0;
    }
}