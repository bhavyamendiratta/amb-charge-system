package com.example.drools.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoanApplication {
    private String applicationId;
    private String customerId;
    private int age;
    private double income;
    private double creditScore;
    private String employmentType;
    private int existingLoans;
    private double loanAmount;

    // Output fields
    private boolean eligible;
    private double maxLoanAmount;
    private double interestRate;
    private String reason;
    private boolean approved;
    private double approvedAmount;
    private String message;
}