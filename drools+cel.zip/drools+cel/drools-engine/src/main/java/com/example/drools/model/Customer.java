package com.example.drools.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Customer {
    private String customerId;
    private String name;
    private double income;
    private String tier;
    private int age;
    private double creditScore;

    // Discount calculation fields
    private double discount;
    private String discountReason;

    // For general use
    private String message;
    private boolean eligible;
}