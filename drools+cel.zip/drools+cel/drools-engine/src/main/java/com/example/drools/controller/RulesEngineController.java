package com.example.drools.controller;

import com.example.drools.model.RulesRequest;
import com.example.drools.model.RulesResponse;
import com.example.drools.service.RulesEngineService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@RequestMapping("/api/rules")
@RequiredArgsConstructor
public class RulesEngineController {

    private final RulesEngineService rulesEngineService;

    /**
     * Execute rules based on rule type
     */
    @PostMapping("/execute")
    public ResponseEntity<RulesResponse> executeRules(@RequestBody RulesRequest request) {
        try {
            RulesResponse response = rulesEngineService.executeRules(request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(RulesResponse.builder()
                            .success(false)
                            .error(e.getMessage())
                            .build());
        }
    }

    /**
     * Execute rules with custom DRL file upload
     */
    @PostMapping("/execute-custom")
    public ResponseEntity<RulesResponse> executeCustomRules(
            @RequestParam("drlFile") MultipartFile drlFile,
            @RequestBody RulesRequest request) {
        try {
            String drlContent = new String(drlFile.getBytes());
            RulesResponse response = rulesEngineService.executeCustomRules(drlContent, request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(RulesResponse.builder()
                            .success(false)
                            .error(e.getMessage())
                            .build());
        }
    }

    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status", "UP",
                "service", "Drools Rules Engine",
                "version", "1.0.0"
        ));
    }
}