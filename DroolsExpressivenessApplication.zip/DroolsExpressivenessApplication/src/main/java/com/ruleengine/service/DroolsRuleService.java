package com.ruleengine.service;

import com.ruleengine.dto.RuleRequest;
import com.ruleengine.dto.RuleResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.Message;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.event.rule.AgendaEventListener;
import org.kie.api.event.rule.DefaultAgendaEventListener;
import org.kie.api.event.rule.AfterMatchFiredEvent;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class DroolsRuleService {

    private final KieServices kieServices;

    public RuleResponse executeRules(RuleRequest request) {
        long startTime = System.currentTimeMillis();
        List<String> firedRules = new ArrayList<>();

        try {
            // Create a new KieFileSystem for dynamic rule loading
            KieFileSystem kieFileSystem = kieServices.newKieFileSystem();

            // Add the DRL content
            String drlPath = "src/main/resources/rules/dynamic-rule.drl";
            kieFileSystem.write(drlPath, request.getDrlContent());

            // Build the rules
            KieBuilder kieBuilder = kieServices.newKieBuilder(kieFileSystem);
            kieBuilder.buildAll();

            // Check for errors
            if (kieBuilder.getResults().hasMessages(Message.Level.ERROR)) {
                StringBuilder errorMsg = new StringBuilder("Rule compilation errors:\n");
                kieBuilder.getResults().getMessages(Message.Level.ERROR)
                        .forEach(msg -> errorMsg.append(msg.getText()).append("\n"));

                return RuleResponse.builder()
                        .success(false)
                        .message(errorMsg.toString())
                        .executionTimeMs(System.currentTimeMillis() - startTime)
                        .build();
            }

            // Create KieContainer
            KieContainer kieContainer = kieServices.newKieContainer(
                    kieBuilder.getKieModule().getReleaseId()
            );

            // Create KieSession
            KieSession kieSession = kieContainer.newKieSession();

            // Add agenda event listener to track fired rules
            kieSession.addEventListener(new DefaultAgendaEventListener() {
                @Override
                public void afterMatchFired(AfterMatchFiredEvent event) {
                    firedRules.add(event.getMatch().getRule().getName());
                }
            });

            // Create a mutable copy of input data for rules to modify
            Map<String, Object> workingData = new HashMap<>(request.getInputData());

            // Insert the map into working memory
            kieSession.insert(workingData);

            // Fire all rules
            int rulesFired = kieSession.fireAllRules();

            // Dispose session
            kieSession.dispose();

            long executionTime = System.currentTimeMillis() - startTime;

            return RuleResponse.builder()
                    .success(true)
                    .message("Rules executed successfully")
                    .outputData(workingData)
                    .firedRules(firedRules)
                    .rulesFiredCount(rulesFired)
                    .executionTimeMs(executionTime)
                    .build();

        } catch (Exception e) {
            log.error("Error executing rules", e);
            return RuleResponse.builder()
                    .success(false)
                    .message("Error executing rules: " + e.getMessage())
                    .executionTimeMs(System.currentTimeMillis() - startTime)
                    .build();
        }
    }

    public RuleResponse validateDrl(String drlContent) {
        try {
            KieFileSystem kieFileSystem = kieServices.newKieFileSystem();
            kieFileSystem.write("src/main/resources/rules/validation.drl", drlContent);

            KieBuilder kieBuilder = kieServices.newKieBuilder(kieFileSystem);
            kieBuilder.buildAll();

            if (kieBuilder.getResults().hasMessages(Message.Level.ERROR)) {
                StringBuilder errorMsg = new StringBuilder("Validation errors:\n");
                kieBuilder.getResults().getMessages(Message.Level.ERROR)
                        .forEach(msg -> errorMsg.append(msg.getText()).append("\n"));

                return RuleResponse.builder()
                        .success(false)
                        .message(errorMsg.toString())
                        .build();
            }

            return RuleResponse.builder()
                    .success(true)
                    .message("DRL is valid")
                    .build();

        } catch (Exception e) {
            return RuleResponse.builder()
                    .success(false)
                    .message("Validation error: " + e.getMessage())
                    .build();
        }
    }
}