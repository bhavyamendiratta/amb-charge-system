package com.ruleengine.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RuleResponse {

    private boolean success;
    private String message;
    private Map<String, Object> outputData;
    private List<String> firedRules;
    private int rulesFiredCount;
    private long executionTimeMs;
    private Map<String, Object> additionalInfo;
}