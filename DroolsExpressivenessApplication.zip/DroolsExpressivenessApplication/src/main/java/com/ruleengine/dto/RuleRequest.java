package com.ruleengine.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RuleRequest {

    @NotBlank(message = "DRL content cannot be empty")
    private String drlContent;

    @NotNull(message = "Input data cannot be null")
    private Map<String, Object> inputData;

    private String ruleName; // Optional: for identification
}