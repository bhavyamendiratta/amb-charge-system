package com.ruleengine.controller;

import com.ruleengine.dto.RuleRequest;
import com.ruleengine.dto.RuleResponse;
import com.ruleengine.service.DroolsRuleService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/rules")
@RequiredArgsConstructor
@Slf4j
@Validated
public class RuleController {

    private final DroolsRuleService droolsRuleService;

    @PostMapping("/execute")
    public ResponseEntity<RuleResponse> executeRules(@Valid @RequestBody RuleRequest request) {
        log.info("Executing rules for: {}", request.getRuleName());
        RuleResponse response = droolsRuleService.executeRules(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/validate")
    public ResponseEntity<RuleResponse> validateDrl(@RequestBody String drlContent) {
        log.info("Validating DRL content");
        RuleResponse response = droolsRuleService.validateDrl(drlContent);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Drools Rule Engine is running");
    }
}