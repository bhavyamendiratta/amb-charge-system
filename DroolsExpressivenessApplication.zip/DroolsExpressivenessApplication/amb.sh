#!/bin/bash

# ========================================================================
# AMB DEFAULTER DETECTION - cURL TEST SUITE
# Map-Based Drools Implementation
# ========================================================================

BASE_URL="http://localhost:8080/drools-evaluator/api/rules"

echo "========================================================================"
echo "AMB DEFAULTER DETECTION - MAP-BASED DROOLS"
echo "========================================================================"
echo ""

# Read the DRL file content (you'll need to inline it or read from file)
# For demo, we'll inline a simplified version

# ========================================================================
# TEST 1: Day 25 Check - Probable Defaulters
# ========================================================================

echo "========================================================================="
echo "TEST 1: DAY 25 CHECK - PROBABLE DEFAULTER DETECTION"
echo "========================================================================="
echo ""

curl -X POST "http://localhost:8080/drools-evaluator/api/rules/execute" \
  -H "Content-Type: application/json" \
  -d '{
    "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\nimport java.util.List;\nimport java.util.ArrayList;\nimport java.util.HashMap;\n\nfunction double calculateAMB(Map account, int startDay, int endDay) {\n    if (!account.containsKey(\"dailyBalances\")) return 0.0;\n    List dailyBalances = (List)account.get(\"dailyBalances\");\n    double sum = 0.0;\n    int count = 0;\n    for (int day = startDay; day <= endDay && day <= dailyBalances.size(); day++) {\n        Object balanceObj = dailyBalances.get(day - 1);\n        if (balanceObj instanceof Number) {\n            sum += ((Number)balanceObj).doubleValue();\n            count++;\n        }\n    }\n    return count > 0 ? sum / count : 0.0;\n}\n\nfunction boolean checkActualDefaulter(List actualDefaulters, String accountId, int month) {\n    for (Object adObj : actualDefaulters) {\n        if (adObj instanceof Map) {\n            Map ad = (Map)adObj;\n            if (accountId.equals(ad.get(\"accountId\")) && ((Number)ad.get(\"month\")).intValue() == month) return true;\n        }\n    }\n    return false;\n}\n\nrule \"R1B_ProbableDefaulter_New_SendSMS\"\n    salience 100\n    when\n        $data : Map(\n            this[\"checkDay\"] == 25,\n            this[\"accounts\"] instanceof List,\n            this[\"minBalance\"] != null\n        )\n    then\n        List accounts = (List)$data.get(\"accounts\");\n        double minBalance = ((Number)$data.get(\"minBalance\")).doubleValue();\n        int currentMonth = ((Number)$data.get(\"currentMonth\")).intValue();\n        List probableDefaulters = (List)$data.getOrDefault(\"probableDefaulters\", new ArrayList());\n        List actualDefaulters = (List)$data.getOrDefault(\"actualDefaulters\", new ArrayList());\n        \n        for (Object accObj : accounts) {\n            if (accObj instanceof Map) {\n                Map account = (Map)accObj;\n                String accountId = (String)account.get(\"accountId\");\n                String accountName = (String)account.get(\"accountName\");\n                double amb = calculateAMB(account, 1, 25);\n                \n                if (amb < minBalance) {\n                    boolean wasActualDefaulterLastMonth = checkActualDefaulter(actualDefaulters, accountId, currentMonth - 1);\n                    if (!wasActualDefaulterLastMonth) {\n                        Map pd = new HashMap();\n                        pd.put(\"accountId\", accountId);\n                        pd.put(\"accountName\", accountName);\n                        pd.put(\"month\", currentMonth);\n                        pd.put(\"amb\", amb);\n                        pd.put(\"smsSent\", true);\n                        pd.put(\"deficit\", minBalance - amb);\n                        probableDefaulters.add(pd);\n                        System.out.println(\"[RULE 1B] NEW PROBABLE DEFAULTER: \" + accountId + \" (\" + accountName + \") - AMB: \" + String.format(\"%.2f\", amb) + \" - SMS SENT\");\n                    }\n                }\n            }\n        }\n        $data.put(\"probableDefaulters\", probableDefaulters);\nend\n\nrule \"R1C_BalanceMaintained\"\n    salience 90\n    when\n        $data : Map(this[\"checkDay\"] == 25, this[\"accounts\"] instanceof List)\n    then\n        List accounts = (List)$data.get(\"accounts\");\n        double minBalance = ((Number)$data.get(\"minBalance\")).doubleValue();\n        List compliant = new ArrayList();\n        for (Object accObj : accounts) {\n            if (accObj instanceof Map) {\n                Map account = (Map)accObj;\n                String accountId = (String)account.get(\"accountId\");\n                double amb = calculateAMB(account, 1, 25);\n                if (amb >= minBalance) {\n                    Map c = new HashMap();\n                    c.put(\"accountId\", accountId);\n                    c.put(\"amb\", amb);\n                    compliant.add(c);\n                    System.out.println(\"[RULE 1C] COMPLIANT: \" + accountId + \" - AMB: \" + String.format(\"%.2f\", amb));\n                }\n            }\n        }\n        $data.put(\"compliantAccounts\", compliant);\nend",
    "inputData": {
      "checkDay": 25,
      "currentMonth": 3,
      "minBalance": 10000.0,
      "accounts": [
        {
          "accountId": "ACC001",
          "accountName": "Rajesh Kumar",
          "dailyBalances": [
            5000, 5200, 4800, 5100, 4900,
            5300, 5000, 4700, 5200, 4800,
            5100, 4900, 5000, 4800, 5200,
            4900, 5100, 5000, 4800, 5300,
            4900, 5100, 5000, 4700, 5200
          ]
        },
        {
          "accountId": "ACC002",
          "accountName": "Priya Sharma",
          "dailyBalances": [
            12000, 12500, 13000, 12800, 13200,
            12900, 13100, 12700, 13000, 12800,
            13200, 12900, 13100, 12700, 13000,
            12800, 13200, 12900, 13100, 12700,
            13000, 12800, 13200, 12900, 13100
          ]
        }
      ],
      "actualDefaulters": [],
      "probableDefaulters": []
    },
    "ruleName": "AMB_Day25_ProbableDefaulters"
  }' | jq '.'

echo -e "\n\n"

# ========================================================================
# TEST 2: Day 3 Check - Actual Defaulter Detection
# ========================================================================

echo "========================================================================="
echo "TEST 2: DAY 3 CHECK - ACTUAL DEFAULTER DETECTION"
echo "========================================================================="
echo ""

curl -X POST "${BASE_URL}/execute" \
  -H "Content-Type: application/json" \
  -d '{
    "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\nimport java.util.List;\nimport java.util.ArrayList;\nimport java.util.HashMap;\n\nfunction double calculateAMB(Map account, int startDay, int endDay) {\n    if (!account.containsKey(\"dailyBalances\")) return 0.0;\n    List dailyBalances = (List)account.get(\"dailyBalances\");\n    double sum = 0.0;\n    int count = 0;\n    for (int day = startDay; day <= endDay && day <= dailyBalances.size(); day++) {\n        Object balanceObj = dailyBalances.get(day - 1);\n        if (balanceObj instanceof Number) {\n            sum += ((Number)balanceObj).doubleValue();\n            count++;\n        }\n    }\n    return count > 0 ? sum / count : 0.0;\n}\n\nfunction boolean checkProbableDefaulter(List probableDefaulters, String accountId, int month) {\n    for (Object pdObj : probableDefaulters) {\n        if (pdObj instanceof Map) {\n            Map pd = (Map)pdObj;\n            if (accountId.equals(pd.get(\"accountId\")) && ((Number)pd.get(\"month\")).intValue() == month) return true;\n        }\n    }\n    return false;\n}\n\nrule \"R2_ActualDefaulter\"\n    salience 80\n    when\n        $data : Map(\n            this[\"checkDay\"] == 3,\n            this[\"accounts\"] instanceof List,\n            this[\"minBalance\"] != null\n        )\n    then\n        List accounts = (List)$data.get(\"accounts\");\n        double minBalance = ((Number)$data.get(\"minBalance\")).doubleValue();\n        int currentMonth = ((Number)$data.get(\"currentMonth\")).intValue();\n        List probableDefaulters = (List)$data.getOrDefault(\"probableDefaulters\", new ArrayList());\n        List actualDefaulters = (List)$data.getOrDefault(\"actualDefaulters\", new ArrayList());\n        \n        for (Object accObj : accounts) {\n            if (accObj instanceof Map) {\n                Map account = (Map)accObj;\n                String accountId = (String)account.get(\"accountId\");\n                String accountName = (String)account.get(\"accountName\");\n                double amb = calculateAMB(account, 1, 30);\n                \n                if (amb < minBalance) {\n                    boolean wasProbableLastMonth = checkProbableDefaulter(probableDefaulters, accountId, currentMonth - 1);\n                    if (wasProbableLastMonth) {\n                        double shortfall = minBalance - amb;\n                        Map ad = new HashMap();\n                        ad.put(\"accountId\", accountId);\n                        ad.put(\"accountName\", accountName);\n                        ad.put(\"month\", currentMonth - 1);\n                        ad.put(\"amb\", amb);\n                        ad.put(\"shortfall\", shortfall);\n                        ad.put(\"status\", \"Confirmed\");\n                        actualDefaulters.add(ad);\n                        System.out.println(\"[RULE 2] ACTUAL DEFAULTER: \" + accountId + \" - Month \" + (currentMonth-1) + \" - Shortfall: \" + String.format(\"%.2f\", shortfall));\n                    }\n                }\n            }\n        }\n        $data.put(\"actualDefaulters\", actualDefaulters);\nend",
    "inputData": {
      "checkDay": 3,
      "currentMonth": 4,
      "minBalance": 10000.0,
      "accounts": [
        {
          "accountId": "ACC001",
          "accountName": "Rajesh Kumar",
          "dailyBalances": [
            5000, 5200, 4800, 5100, 4900,
            5300, 5000, 4700, 5200, 4800,
            5100, 4900, 5000, 4800, 5200,
            4900, 5100, 5000, 4800, 5300,
            4900, 5100, 5000, 4700, 5200,
            4800, 5100, 4900, 5000, 4800
          ]
        }
      ],
      "probableDefaulters": [
        {
          "accountId": "ACC001",
          "month": 3,
          "amb": 5020.0,
          "smsSent": true
        }
      ],
      "actualDefaulters": []
    },
    "ruleName": "AMB_Day3_ActualDefaulters"
  }' | jq '.'

echo -e "\n\n"

echo "========================================================================="
echo "✅ AMB DEFAULTER DETECTION TESTS COMPLETED!"
echo "========================================================================="
echo ""
echo "Summary:"
echo "1. ✅ Day 25 - Probable defaulter detection with SMS"
echo "2. ✅ Day 3 - Actual defaulter confirmation"
echo ""
echo "Next: Run charge calculation for 2 consecutive months of default"
echo "========================================================================"