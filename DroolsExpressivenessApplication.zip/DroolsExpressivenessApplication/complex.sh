#!/bin/bash

# ========================================================================
# DROOLS COMPLEX RULES - COMPLETE cURL TEST SUITE
# All 10 Advanced Capabilities
# ========================================================================

BASE_URL="http://localhost:8080/drools-evaluator/api/rules"

echo "========================================================================"
echo "DROOLS COMPLEX RULES - COMPLETE TEST SUITE"
echo "Testing all 10 advanced capabilities"
echo "========================================================================"
echo ""

# ========================================================================
# TEST 1: NESTED MAP ACCESS
# ========================================================================

echo "========================================================================="
echo "TEST 1: NESTED MAP ACCESS (Customer Address - Mumbai)"
echo "========================================================================="

curl -X POST "${BASE_URL}/execute" \
  -H "Content-Type: application/json" \
  -d '{
    "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\n\nrule \"Access Nested Customer Data\"\n    when\n        $data : Map(\n            this[\"customer\"] != null,\n            this[\"customer\"] instanceof Map,\n            ((Map)this[\"customer\"]).get(\"address\") instanceof Map,\n            ((Map)((Map)this[\"customer\"]).get(\"address\")).get(\"city\") == \"Mumbai\"\n        )\n    then\n        $data.put(\"cityBasedDiscount\", 5.0);\n        $data.put(\"eligibleForLocalOffer\", true);\nend",
    "inputData": {
      "customer": {
        "name": "Rajesh Kumar",
        "email": "rajesh@example.com",
        "address": {
          "city": "Mumbai",
          "pincode": "400001",
          "state": "Maharashtra"
        }
      },
      "accountType": "SAVINGS"
    },
    "ruleName": "Nested_Map_Access_Test"
  }' | jq '.'

echo -e "\n\n"

# ========================================================================
# TEST 2: ARRAY/LIST PROCESSING
# ========================================================================

echo "========================================================================="
echo "TEST 2: ARRAY/LIST PROCESSING (Transaction History)"
echo "========================================================================="

curl -X POST "${BASE_URL}/execute" \
  -H "Content-Type: application/json" \
  -d '{
    "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\nimport java.util.List;\n\nrule \"Process Transaction History\"\n    when\n        $data : Map(\n            this[\"transactions\"] != null,\n            this[\"transactions\"] instanceof List,\n            ((List)this[\"transactions\"]).size() > 10\n        )\n    then\n        List transactions = (List)$data.get(\"transactions\");\n        int highValueCount = 0;\n        \n        for (Object tx : transactions) {\n            if (tx instanceof Map) {\n                Map txMap = (Map)tx;\n                Object amount = txMap.get(\"amount\");\n                if (amount != null && (Double)amount > 50000) {\n                    highValueCount++;\n                }\n            }\n        }\n        \n        $data.put(\"highValueTransactionCount\", highValueCount);\n        if (highValueCount >= 5) {\n            $data.put(\"premiumCustomer\", true);\n            $data.put(\"creditLimitIncrease\", 100000);\n        }\nend",
    "inputData": {
      "customerId": "C12345",
      "transactions": [
        {"amount": 60000, "date": "2025-01-15", "type": "TRANSFER"},
        {"amount": 75000, "date": "2025-02-10", "type": "WITHDRAWAL"},
        {"amount": 55000, "date": "2025-03-05", "type": "PAYMENT"},
        {"amount": 80000, "date": "2025-04-20", "type": "TRANSFER"},
        {"amount": 90000, "date": "2025-05-12", "type": "PAYMENT"},
        {"amount": 45000, "date": "2025-06-08", "type": "WITHDRAWAL"},
        {"amount": 70000, "date": "2025-07-15", "type": "TRANSFER"},
        {"amount": 65000, "date": "2025-08-22", "type": "PAYMENT"},
        {"amount": 85000, "date": "2025-09-18", "type": "WITHDRAWAL"},
        {"amount": 95000, "date": "2025-10-25", "type": "TRANSFER"},
        {"amount": 100000, "date": "2025-11-10", "type": "PAYMENT"}
      ]
    },
    "ruleName": "Array_Processing_Test"
  }' | jq '.'

echo -e "\n\n"

# ========================================================================
# TEST 3: COMPLEX MATHEMATICAL CALCULATIONS
# ========================================================================

echo "========================================================================="
echo "TEST 3: COMPLEX CREDIT SCORE CALCULATION"
echo "========================================================================="

curl -X POST "${BASE_URL}/execute" \
  -H "Content-Type: application/json" \
  -d '{
    "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\n\nrule \"Calculate Comprehensive Credit Score\"\n    salience 100\n    when\n        $data : Map(\n            this[\"monthlyIncome\"] != null,\n            this[\"existingLoans\"] != null,\n            this[\"creditHistory\"] != null,\n            this[\"age\"] != null\n        )\n    then\n        double income = (Double)$data.get(\"monthlyIncome\");\n        int existingLoans = (Integer)$data.get(\"existingLoans\");\n        int creditHistory = (Integer)$data.get(\"creditHistory\");\n        int age = (Integer)$data.get(\"age\");\n        \n        double incomeScore = Math.min(income / 1000, 100);\n        double loanScore = Math.max(0, 100 - (existingLoans * 10));\n        double historyScore = Math.min(creditHistory / 2.0, 100);\n        double ageScore = (age >= 25 && age <= 55) ? 100 : 50;\n        \n        double finalScore = (incomeScore * 0.3) + (loanScore * 0.25) + (historyScore * 0.35) + (ageScore * 0.1);\n        \n        $data.put(\"calculatedCreditScore\", finalScore);\n        $data.put(\"scoreBreakdown\", java.util.Map.of(\n            \"incomeScore\", incomeScore,\n            \"loanScore\", loanScore,\n            \"historyScore\", historyScore,\n            \"ageScore\", ageScore\n        ));\nend",
    "inputData": {
      "monthlyIncome": 120000.0,
      "existingLoans": 2,
      "creditHistory": 48,
      "age": 35
    },
    "ruleName": "Credit_Score_Calculation"
  }' | jq '.'

echo -e "\n\n"

# ========================================================================
# TEST 4: MULTIPLE CONDITIONS WITH AND/OR LOGIC
# ========================================================================

echo "========================================================================="
echo "TEST 4: PREMIUM LOAN ELIGIBILITY (Complex AND/OR Logic)"
echo "========================================================================="

curl -X POST "${BASE_URL}/execute" \
  -H "Content-Type: application/json" \
  -d '{
    "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\n\nrule \"Calculate Credit Score First\"\n    salience 110\n    when\n        $data : Map(\n            this[\"monthlyIncome\"] != null,\n            this[\"existingLoans\"] != null,\n            this[\"creditHistory\"] != null,\n            this[\"age\"] != null\n        )\n    then\n        double income = (Double)$data.get(\"monthlyIncome\");\n        int existingLoans = (Integer)$data.get(\"existingLoans\");\n        int creditHistory = (Integer)$data.get(\"creditHistory\");\n        int age = (Integer)$data.get(\"age\");\n        double incomeScore = Math.min(income / 1000, 100);\n        double loanScore = Math.max(0, 100 - (existingLoans * 10));\n        double historyScore = Math.min(creditHistory / 2.0, 100);\n        double ageScore = (age >= 25 && age <= 55) ? 100 : 50;\n        double finalScore = (incomeScore * 0.3) + (loanScore * 0.25) + (historyScore * 0.35) + (ageScore * 0.1);\n        $data.put(\"calculatedCreditScore\", finalScore);\nend\n\nrule \"Premium Loan Eligibility\"\n    when\n        $data : Map(\n            this[\"calculatedCreditScore\"] != null,\n            $score : this[\"calculatedCreditScore\"],\n            $score > 70,\n            (this[\"employmentType\"] == \"SALARIED\" || this[\"businessYears\"] >= 5),\n            this[\"monthlyIncome\"] != null,\n            $income : this[\"monthlyIncome\"],\n            $income > 75000,\n            this[\"existingEMI\"] != null,\n            $existingEMI : this[\"existingEMI\"],\n            $existingEMI < ($income * 0.4),\n            (this[\"ownsProperty\"] == true || $score > 85)\n        )\n    then\n        $data.put(\"loanEligible\", true);\n        $data.put(\"loanType\", \"PREMIUM\");\n        $data.put(\"maxLoanAmount\", (Double)$income * 80);\n        $data.put(\"interestRate\", 7.5);\n        if ((Boolean)$data.getOrDefault(\"ownsProperty\", false)) {\n            $data.put(\"interestRate\", 7.0);\n            $data.put(\"processingFeeWaived\", true);\n        }\nend",
    "inputData": {
      "monthlyIncome": 150000.0,
      "existingLoans": 1,
      "creditHistory": 60,
      "age": 35,
      "employmentType": "SALARIED",
      "existingEMI": 30000.0,
      "ownsProperty": true
    },
    "ruleName": "Premium_Loan_Eligibility"
  }' | jq '.'

echo -e "\n\n"

# ========================================================================
# TEST 5: RULE CHAINING (Multi-Step Risk Assessment)
# ========================================================================

echo "========================================================================="
echo "TEST 5: RULE CHAINING (4-Step Risk Assessment)"
echo "========================================================================="

curl -X POST "${BASE_URL}/execute" \
  -H "Content-Type: application/json" \
  -d '{
    "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\nimport java.util.HashMap;\nimport java.util.List;\nimport java.util.ArrayList;\n\nrule \"Step 1: Initialize Risk Assessment\"\n    salience 100\n    when\n        $data : Map(this[\"riskAssessment\"] == null)\n    then\n        Map<String, Object> riskData = new HashMap<>();\n        riskData.put(\"riskScore\", 0);\n        riskData.put(\"riskFactors\", new ArrayList<String>());\n        $data.put(\"riskAssessment\", riskData);\nend\n\nrule \"Step 2: Assess Credit Risk\"\n    salience 90\n    when\n        $data : Map(\n            this[\"riskAssessment\"] instanceof Map,\n            this[\"calculatedCreditScore\"] != null,\n            $score : this[\"calculatedCreditScore\"],\n            $score < 60\n        )\n    then\n        Map riskData = (Map)$data.get(\"riskAssessment\");\n        riskData.put(\"riskScore\", (Integer)riskData.get(\"riskScore\") + 30);\n        ((List)riskData.get(\"riskFactors\")).add(\"LOW_CREDIT_SCORE\");\nend\n\nrule \"Step 3: Assess Income Risk\"\n    salience 80\n    when\n        $data : Map(\n            this[\"riskAssessment\"] instanceof Map,\n            this[\"monthlyIncome\"] != null,\n            this[\"loanAmount\"] != null,\n            $income : this[\"monthlyIncome\"],\n            $loanAmount : this[\"loanAmount\"],\n            $loanAmount > ($income * 50)\n        )\n    then\n        Map riskData = (Map)$data.get(\"riskAssessment\");\n        riskData.put(\"riskScore\", (Integer)riskData.get(\"riskScore\") + 25);\n        ((List)riskData.get(\"riskFactors\")).add(\"HIGH_LOAN_TO_INCOME_RATIO\");\nend\n\nrule \"Step 4: Final Risk Decision\"\n    salience 70\n    when\n        $data : Map(\n            this[\"riskAssessment\"] instanceof Map,\n            ((Map)this[\"riskAssessment\"]).get(\"riskScore\") != null,\n            $riskScore : ((Map)this[\"riskAssessment\"]).get(\"riskScore\"),\n            $riskScore > 40\n        )\n    then\n        $data.put(\"loanEligible\", false);\n        $data.put(\"rejectionReason\", \"HIGH_RISK_PROFILE\");\n        $data.put(\"riskLevel\", \"HIGH\");\nend",
    "inputData": {
      "monthlyIncome": 40000.0,
      "loanAmount": 3000000.0,
      "calculatedCreditScore": 55.0
    },
    "ruleName": "Rule_Chaining_Test"
  }' | jq '.'

echo -e "\n\n"

# ========================================================================
# TEST 6: TEMPORAL/DATE CALCULATIONS (EMI & Tenure)
# ========================================================================

echo "========================================================================="
echo "TEST 6: LOAN TENURE & EMI CALCULATION"
echo "========================================================================="

curl -X POST "${BASE_URL}/execute" \
  -H "Content-Type: application/json" \
  -d '{
    "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\n\nrule \"Calculate Loan Tenure Based on Age\"\n    when\n        $data : Map(\n            this[\"age\"] != null,\n            this[\"loanAmount\"] != null,\n            this[\"monthlyIncome\"] != null,\n            $age : this[\"age\"],\n            $loanAmount : this[\"loanAmount\"],\n            $income : this[\"monthlyIncome\"]\n        )\n    then\n        int maxTenureYears;\n        if ($age < 30) {\n            maxTenureYears = 30;\n        } else if ($age < 45) {\n            maxTenureYears = 25;\n        } else if ($age < 55) {\n            maxTenureYears = 20;\n        } else {\n            maxTenureYears = Math.min(15, 65 - $age);\n        }\n        double monthlyRate = 0.085 / 12;\n        int tenureMonths = maxTenureYears * 12;\n        double emi = ((Double)$loanAmount * monthlyRate * Math.pow(1 + monthlyRate, tenureMonths)) / (Math.pow(1 + monthlyRate, tenureMonths) - 1);\n        $data.put(\"maxTenureYears\", maxTenureYears);\n        $data.put(\"monthlyEMI\", Math.round(emi * 100.0) / 100.0);\n        $data.put(\"totalPayable\", Math.round(emi * tenureMonths * 100.0) / 100.0);\n        if (emi > ((Double)$income * 0.5)) {\n            $data.put(\"emiAffordable\", false);\n        } else {\n            $data.put(\"emiAffordable\", true);\n        }\nend",
    "inputData": {
      "age": 32,
      "loanAmount": 2500000.0,
      "monthlyIncome": 100000.0
    },
    "ruleName": "EMI_Calculation"
  }' | jq '.'

echo -e "\n\n"

# ========================================================================
# TEST 7: DYNAMIC TIERING & CATEGORIZATION
# ========================================================================

echo "========================================================================="
echo "TEST 7: CUSTOMER TIER CATEGORIZATION (Platinum Tier)"
echo "========================================================================="

curl -X POST "${BASE_URL}/execute" \
  -H "Content-Type: application/json" \
  -d '{
    "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\nimport java.util.HashMap;\n\nrule \"Categorize Customer Tier\"\n    when\n        $data : Map(\n            this[\"monthlyIncome\"] != null,\n            this[\"totalRelationshipValue\"] != null,\n            this[\"accountAge\"] != null,\n            $income : this[\"monthlyIncome\"],\n            $relationshipValue : this[\"totalRelationshipValue\"],\n            $accountAge : this[\"accountAge\"]\n        )\n    then\n        String tier;\n        Map<String, Object> benefits = new HashMap<>();\n        int tierScore = 0;\n        if ((Double)$income > 200000) tierScore += 40;\n        else if ((Double)$income > 100000) tierScore += 25;\n        else if ((Double)$income > 50000) tierScore += 10;\n        if ((Double)$relationshipValue > 5000000) tierScore += 40;\n        else if ((Double)$relationshipValue > 1000000) tierScore += 25;\n        else if ((Double)$relationshipValue > 500000) tierScore += 10;\n        if ((Integer)$accountAge > 60) tierScore += 20;\n        else if ((Integer)$accountAge > 24) tierScore += 10;\n        if (tierScore >= 80) {\n            tier = \"PLATINUM\";\n            benefits.put(\"freeTransactions\", \"UNLIMITED\");\n            benefits.put(\"loungeAccess\", true);\n            benefits.put(\"dedicatedRM\", true);\n        } else if (tierScore >= 50) {\n            tier = \"GOLD\";\n            benefits.put(\"freeTransactions\", 50);\n            benefits.put(\"loungeAccess\", true);\n        } else {\n            tier = \"BASIC\";\n            benefits.put(\"freeTransactions\", 10);\n        }\n        $data.put(\"customerTier\", tier);\n        $data.put(\"tierScore\", tierScore);\n        $data.put(\"benefits\", benefits);\nend",
    "inputData": {
      "monthlyIncome": 250000.0,
      "totalRelationshipValue": 6000000.0,
      "accountAge": 72
    },
    "ruleName": "Tier_Categorization"
  }' | jq '.'

echo -e "\n\n"

# ========================================================================
# TEST 8: EXCEPTION HANDLING (NRI Special Benefits)
# ========================================================================

echo "========================================================================="
echo "TEST 8: NRI CUSTOMER SPECIAL BENEFITS"
echo "========================================================================="

curl -X POST "${BASE_URL}/execute" \
  -H "Content-Type: application/json" \
  -d '{
    "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\n\nrule \"NRI Customer Premium Benefits\"\n    salience 95\n    when\n        $data : Map(\n            this[\"customerType\"] == \"NRI\",\n            this[\"monthlyIncome\"] != null,\n            $income : this[\"monthlyIncome\"],\n            $income > 100000\n        )\n    then\n        $data.put(\"specialCategory\", \"NRI_PREMIUM\");\n        $data.put(\"freeRemittance\", true);\n        $data.put(\"forexCardFree\", true);\n        $data.put(\"nriAccountBenefits\", true);\n        if ($data.containsKey(\"interestRate\")) {\n            double currentRate = (Double)$data.get(\"interestRate\");\n            $data.put(\"interestRate\", currentRate - 0.5);\n            $data.put(\"rateDiscount\", 0.5);\n        }\nend",
    "inputData": {
      "customerType": "NRI",
      "monthlyIncome": 150000.0,
      "interestRate": 8.5
    },
    "ruleName": "NRI_Benefits"
  }' | jq '.'

echo -e "\n\n"

# ========================================================================
# TEST 9: COMPLEX BUSINESS VALIDATION
# ========================================================================

echo "========================================================================="
echo "TEST 9: DATA VALIDATION (Invalid Inputs)"
echo "========================================================================="

curl -X POST "${BASE_URL}/execute" \
  -H "Content-Type: application/json" \
  -d '{
    "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\nimport java.util.List;\nimport java.util.ArrayList;\n\nrule \"Validate and Clean Input Data\"\n    salience 200\n    when\n        $data : Map()\n    then\n        List<String> validationErrors = new ArrayList<>();\n        if ($data.get(\"age\") != null) {\n            int age = (Integer)$data.get(\"age\");\n            if (age < 18 || age > 100) {\n                validationErrors.add(\"Invalid age: must be between 18 and 100\");\n            }\n        }\n        if ($data.get(\"monthlyIncome\") != null) {\n            double income = (Double)$data.get(\"monthlyIncome\");\n            if (income < 0) {\n                validationErrors.add(\"Invalid income: cannot be negative\");\n            }\n        }\n        if ($data.get(\"loanAmount\") != null) {\n            double loanAmount = (Double)$data.get(\"loanAmount\");\n            if (loanAmount < 50000 || loanAmount > 50000000) {\n                validationErrors.add(\"Loan amount must be between 50,000 and 5,00,00,000\");\n            }\n        }\n        if (!validationErrors.isEmpty()) {\n            $data.put(\"validationErrors\", validationErrors);\n            $data.put(\"validationFailed\", true);\n        } else {\n            $data.put(\"validationPassed\", true);\n        }\nend",
    "inputData": {
      "age": 150,
      "monthlyIncome": -50000.0,
      "loanAmount": 100000000.0
    },
    "ruleName": "Data_Validation"
  }' | jq '.'

echo -e "\n\n"

# ========================================================================
# TEST 10: MULTI-PRODUCT CROSS-SELL
# ========================================================================

echo "========================================================================="
echo "TEST 10: CROSS-SELL RECOMMENDATIONS ENGINE"
echo "========================================================================="

curl -X POST "${BASE_URL}/execute" \
  -H "Content-Type: application/json" \
  -d '{
    "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\nimport java.util.List;\nimport java.util.ArrayList;\n\nrule \"Cross-Sell Opportunities\"\n    when\n        $data : Map(\n            this[\"customerTier\"] != null,\n            this[\"monthlyIncome\"] != null,\n            this[\"age\"] != null,\n            $tier : this[\"customerTier\"],\n            $income : this[\"monthlyIncome\"],\n            $age : this[\"age\"]\n        )\n    then\n        List<Map<String, Object>> recommendations = new ArrayList<>();\n        if ((Double)$income > 50000 && !$data.containsKey(\"hasCreditCard\")) {\n            recommendations.add(java.util.Map.of(\n                \"product\", \"CREDIT_CARD\",\n                \"variant\", $tier.equals(\"PLATINUM\") ? \"PLATINUM_CARD\" : \"GOLD_CARD\",\n                \"reason\", \"Based on your income and customer tier\"\n            ));\n        }\n        if ((Double)$income > 100000 && (Integer)$age < 50) {\n            recommendations.add(java.util.Map.of(\n                \"product\", \"MUTUAL_FUND_SIP\",\n                \"recommendedAmount\", (Double)$income * 0.15,\n                \"reason\", \"Long-term wealth creation\"\n            ));\n        }\n        if ((Integer)$age >= 25 && (Integer)$age <= 50) {\n            recommendations.add(java.util.Map.of(\n                \"product\", \"TERM_INSURANCE\",\n                \"coverAmount\", (Double)$income * 120,\n                \"reason\", \"Financial security for your family\"\n            ));\n        }\n        if (!recommendations.isEmpty()) {\n            $data.put(\"crossSellRecommendations\", recommendations);\n            $data.put(\"recommendationCount\", recommendations.size());\n        }\nend",
    "inputData": {
      "customerTier": "PLATINUM",
      "monthlyIncome": 180000.0,
      "age": 35
    },
    "ruleName": "Cross_Sell"
  }' | jq '.'

echo -e "\n\n"

echo "========================================================================"
echo "✅ ALL 10 COMPLEX TESTS COMPLETED!"
echo "========================================================================"
echo ""
echo "Summary of Tests:"
echo "1. ✅ Nested Map Access"
echo "2. ✅ Array/List Processing"
echo "3. ✅ Complex Mathematical Calculations"
echo "4. ✅ Multiple AND/OR Conditions"
echo "5. ✅ Rule Chaining (4 steps)"
echo "6. ✅ Temporal/EMI Calculations"
echo "7. ✅ Dynamic Tiering"
echo "8. ✅ Exception Handling (NRI)"
echo "9. ✅ Business Validation"
echo "10. ✅ Cross-Sell Engine"
echo "========================================================================"