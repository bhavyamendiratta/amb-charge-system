#!/bin/bash

# Drools Expressiveness Evaluator - Test Script
# This script provides easy testing of various rule scenarios

BASE_URL="http://localhost:8080/drools-evaluator/api/rules"

echo "======================================="
echo "Drools Expressiveness Evaluator Tests"
echo "======================================="
echo ""

# Function to test health endpoint
test_health() {
    echo "1. Testing Health Check..."
    curl -s -X GET "http://localhost:8080/drools-evaluator/api/rules/health"
    echo -e "\n"
}

# Function to test AMB defaulter
test_amb_defaulter() {
    echo "2. Testing AMB Defaulter Detection..."
    curl -s -X POST "http://localhost:8080/drools-evaluator/api/rules/execute" \
        -H "Content-Type: application/json" \
        -d '{
            "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\n\nrule \"Check AMB Shortfall\"\n    when\n        $data : Map(\n            this[\"accountType\"] == \"SAVINGS\",\n            $balance : this[\"currentBalance\"],\n            $ambRequired : this[\"ambRequired\"],\n            $balance < $ambRequired\n        )\n    then\n        $data.put(\"isDefaulter\", true);\n        $data.put(\"shortfall\", (Double)$ambRequired - (Double)$balance);\n        $data.put(\"penalty\", ((Double)$ambRequired - (Double)$balance) * 0.05);\n        $data.put(\"status\", \"AMB_DEFAULTER\");\nend",
            "inputData": {
                "accountType": "SAVINGS",
                "currentBalance": 3000.0,
                "ambRequired": 10000.0
            },
            "ruleName": "AMB_Defaulter_Test"
        }' | jq '.'
    echo ""
}

# Function to test senior citizen waiver
test_senior_citizen_waiver() {
    echo "3. Testing Senior Citizen Waiver..."
    curl -s -X POST "http://localhost:8080/drools-evaluator/api/rules/execute" \
        -H "Content-Type: application/json" \
        -d '{
            "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\n\nrule \"Check AMB Shortfall\"\n    when\n        $data : Map(\n            this[\"accountType\"] == \"SAVINGS\",\n            $balance : this[\"currentBalance\"],\n            $ambRequired : this[\"ambRequired\"],\n            $balance < $ambRequired\n        )\n    then\n        $data.put(\"isDefaulter\", true);\n        $data.put(\"shortfall\", (Double)$ambRequired - (Double)$balance);\nend\n\nrule \"Apply Senior Citizen Waiver\"\n    when\n        $data : Map(\n            this[\"isDefaulter\"] == true,\n            this[\"customerAge\"] != null,\n            $age : this[\"customerAge\"],\n            $age >= 60\n        )\n    then\n        $data.put(\"waiver\", true);\n        $data.put(\"penalty\", 0.0);\n        $data.put(\"waiverReason\", \"SENIOR_CITIZEN\");\nend",
            "inputData": {
                "accountType": "SAVINGS",
                "currentBalance": 2000.0,
                "ambRequired": 10000.0,
                "customerAge": 65
            },
            "ruleName": "Senior_Citizen_Waiver_Test"
        }' | jq '.'
    echo ""
}

# Function to test loan eligibility
test_loan_eligibility() {
    echo "4. Testing Loan Eligibility (Approved)..."
    curl -s -X POST "http://localhost:8080/drools-evaluator/api/rules/execute" \
        -H "Content-Type: application/json" \
        -d '{
            "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\n\nrule \"Check Credit Score\"\n    when\n        $data : Map(\n            this[\"creditScore\"] != null,\n            $score : this[\"creditScore\"],\n            $score >= 750\n        )\n    then\n        $data.put(\"eligible\", true);\n        $data.put(\"interestRate\", 8.5);\n        $data.put(\"loanStatus\", \"APPROVED\");\n        $data.put(\"rateCategory\", \"EXCELLENT\");\nend",
            "inputData": {
                "creditScore": 780,
                "age": 30,
                "monthlyIncome": 80000.0
            },
            "ruleName": "Loan_Eligibility_Approved"
        }' | jq '.'
    echo ""
}

# Function to test charge calculation
test_charge_calculation() {
    echo "5. Testing Charge Calculation with GST..."
    curl -s -X POST "http://localhost:8080/drools-evaluator/api/rules/execute" \
        -H "Content-Type: application/json" \
        -d '{
            "drlContent": "package com.ruleengine.rules;\nimport java.util.Map;\n\nrule \"ATM Withdrawal Charge\"\n    when\n        $data : Map(\n            this[\"transactionType\"] == \"ATM_WITHDRAWAL\",\n            this[\"bankType\"] == \"OTHER_BANK\"\n        )\n    then\n        $data.put(\"totalCharges\", 20.0);\n        $data.put(\"chargeType\", \"ATM_OTHER_BANK\");\nend\n\nrule \"Apply GST\"\n    salience -10\n    when\n        $data : Map(\n            this[\"totalCharges\"] != null,\n            $charges : this[\"totalCharges\"],\n            $charges > 0\n        )\n    then\n        Double gst = (Double)$charges * 0.18;\n        $data.put(\"gst\", gst);\n        $data.put(\"finalAmount\", (Double)$charges + gst);\nend",
            "inputData": {
                "transactionType": "ATM_WITHDRAWAL",
                "bankType": "OTHER_BANK",
                "freeTransactionsUsed": 6
            },
            "ruleName": "Charge_Calculation_Test"
        }' | jq '.'
    echo ""
}

# Function to test invalid DRL
test_invalid_drl() {
    echo "6. Testing Invalid DRL (Error Handling)..."
    curl -s -X POST "http://localhost:8080/drools-evaluator/api/rules/execute" \
        -H "Content-Type: application/json" \
        -d '{
            "drlContent": "package com.ruleengine.rules;\n\nrule \"Invalid\"\n    when\n    then\n        $data.put(\"test\");\nend",
            "inputData": {},
            "ruleName": "Invalid_DRL_Test"
        }' | jq '.'
    echo ""
}

# Run all tests
main() {
    test_health
    test_amb_defaulter
    test_senior_citizen_waiver
    test_loan_eligibility
    test_charge_calculation
    test_invalid_drl

    echo "======================================="
    echo "All tests completed!"
    echo "======================================="
}

# Check if jq is installed
if ! command -v jq &> /dev/null; then
    echo "Warning: 'jq' is not installed. Install it for better JSON formatting."
    echo "On Ubuntu/Debian: sudo apt-get install jq"
    echo "On macOS: brew install jq"
    echo ""
fi

# Run main function
main