package com.gorules.library.example;

import com.gorules.library.DynamoDBRuleRepository;
import com.gorules.library.RuleExecutorById;
import com.gorules.library.RulesExecutor;
import com.gorules.library.RulesExecutorImpl;
import com.gorules.library.config.DynamoDBConfig;
import com.gorules.library.model.RuleExecutionResponse;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;

import java.util.HashMap;
import java.util.Map;

public class UsageExample {

    public static void main(String[] args) {
        // Initialize DynamoDB client
        DynamoDbClient dynamoDbClient = DynamoDBConfig.createDynamoDbClient("ap-south-1");

        // Create repository
        DynamoDBRuleRepository repository = new DynamoDBRuleRepository(
                dynamoDbClient,
                "gorules-table"
        );

        // Create executor (implements both interfaces)
        RulesExecutorImpl executor = new RulesExecutorImpl(repository);

        // Prepare input data for loan application
        Map<String, Object> inputData = new HashMap<>();
        inputData.put("age", 30);
        inputData.put("income", 75000);
        inputData.put("creditScore", 720);
        inputData.put("employmentType", "salaried");
        inputData.put("existingLoans", 1);
        inputData.put("loanAmount", 2000000);

        // Example 1: Execute all rules
        System.out.println("=== Executing All Rules ===");
        RuleExecutionResponse allRulesResponse = executor.executeAllRules(inputData);
        System.out.println("Success: " + allRulesResponse.isSuccess());
        System.out.println("Result: " + allRulesResponse.getResult());
        System.out.println("Execution Time: " + allRulesResponse.getExecutionTimeMs() + "ms\n");

        // Example 2: Execute specific rule by ID
        System.out.println("=== Executing Single Rule by ID ===");
        RuleExecutionResponse singleRuleResponse = executor.executeRuleById(
                "loan-eligibility-rule",
                inputData
        );
        System.out.println("Success: " + singleRuleResponse.isSuccess());
        System.out.println("Result: " + singleRuleResponse.getResult());
        System.out.println("Rule ID: " + singleRuleResponse.getRuleId());
        System.out.println("Execution Time: " + singleRuleResponse.getExecutionTimeMs() + "ms\n");

        // Using as specific interface types
        RulesExecutor allRulesExecutor = executor;
        RuleExecutorById byIdExecutor = executor;

        // Clean up
        dynamoDbClient.close();
    }
}