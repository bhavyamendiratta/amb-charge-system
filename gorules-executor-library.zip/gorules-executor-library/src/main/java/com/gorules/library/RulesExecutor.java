package com.gorules.library;

import com.gorules.library.model.RuleExecutionRequest;
import com.gorules.library.model.RuleExecutionResponse;

import java.util.Map;

/**
 * Interface for executing all rules against the provided input data
 */
public interface RulesExecutor {

    /**
     * Execute all rules from DynamoDB against the given input data
     *
     * @param inputData The input data map to evaluate against all rules
     * @return RuleExecutionResponse containing results from all rules
     */
    RuleExecutionResponse executeAllRules(Map<String, Object> inputData);

    /**
     * Execute all rules from DynamoDB against the given request
     *
     * @param request The rule execution request containing input data
     * @return RuleExecutionResponse containing results from all rules
     */
    RuleExecutionResponse executeAllRules(RuleExecutionRequest request);
}