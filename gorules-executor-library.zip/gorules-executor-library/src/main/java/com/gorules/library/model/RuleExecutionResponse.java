package com.gorules.library.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RuleExecutionResponse {
    private boolean success;
    private Map<String, Object> result;
    private String error;
    private String ruleId;
    private long executionTimeMs;
}