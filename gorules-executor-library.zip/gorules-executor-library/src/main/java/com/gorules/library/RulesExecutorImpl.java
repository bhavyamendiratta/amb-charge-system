package com.gorules.library;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gorules.library.model.RuleExecutionRequest;
import com.gorules.library.model.RuleExecutionResponse;
import io.gorules.zen_engine.JsonBuffer;
import io.gorules.zen_engine.ZenDecisionLoaderCallback;
import io.gorules.zen_engine.ZenEngine;
import io.gorules.zen_engine.ZenEngineResponse;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * Implementation of both RulesExecutor and RuleExecutorById interfaces
 */
@Slf4j
public class RulesExecutorImpl implements RulesExecutor, RuleExecutorById {

    private final DynamoDBRuleRepository ruleRepository;
    private final ObjectMapper objectMapper;
    private final ZenEngine zenEngine;

    public RulesExecutorImpl(DynamoDBRuleRepository ruleRepository) {
        this.ruleRepository = ruleRepository;
        this.objectMapper = new ObjectMapper();

        // Create loader callback for ZenEngine
        ZenDecisionLoaderCallback loaderCallback = (key) -> {
            String rulesJson = ruleRepository.getRuleById(key);
            return CompletableFuture.completedFuture(new JsonBuffer(rulesJson));
        };

        this.zenEngine = new ZenEngine(loaderCallback, null);
    }

    @Override
    public RuleExecutionResponse executeAllRules(Map<String, Object> inputData) {
        return executeAllRules(RuleExecutionRequest.builder()
                .data(inputData)
                .build());
    }

    @Override
    public RuleExecutionResponse executeAllRules(RuleExecutionRequest request) {
        long startTime = System.currentTimeMillis();

        try {
            // Get all rule IDs from DynamoDB
            List<String> ruleIds = ruleRepository.getAllRuleIds();

            if (ruleIds.isEmpty()) {
                log.warn("No rules found in DynamoDB");
                return RuleExecutionResponse.builder()
                        .success(false)
                        .error("No rules found in database")
                        .executionTimeMs(System.currentTimeMillis() - startTime)
                        .build();
            }

            // Execute all rules and collect results
            List<Map<String, Object>> allResults = new ArrayList<>();
            Map<String, String> errors = new HashMap<>();

            for (String ruleId : ruleIds) {
                try {
                    RuleExecutionResponse response = executeRuleById(ruleId, request);
                    if (response.isSuccess()) {
                        Map<String, Object> ruleResult = new HashMap<>();
                        ruleResult.put("ruleId", ruleId);
                        ruleResult.put("result", response.getResult());
                        allResults.add(ruleResult);
                    } else {
                        errors.put(ruleId, response.getError());
                    }
                } catch (Exception e) {
                    log.error("Error executing rule: {}", ruleId, e);
                    errors.put(ruleId, e.getMessage());
                }
            }

            Map<String, Object> combinedResult = new HashMap<>();
            combinedResult.put("results", allResults);
            combinedResult.put("totalRules", ruleIds.size());
            combinedResult.put("successfulRules", allResults.size());

            if (!errors.isEmpty()) {
                combinedResult.put("errors", errors);
            }

            long executionTime = System.currentTimeMillis() - startTime;

            return RuleExecutionResponse.builder()
                    .success(true)
                    .result(combinedResult)
                    .executionTimeMs(executionTime)
                    .build();

        } catch (Exception e) {
            log.error("Error executing all rules", e);
            return RuleExecutionResponse.builder()
                    .success(false)
                    .error("Failed to execute all rules: " + e.getMessage())
                    .executionTimeMs(System.currentTimeMillis() - startTime)
                    .build();
        }
    }

    @Override
    public RuleExecutionResponse executeRuleById(String ruleId, Map<String, Object> inputData) {
        return executeRuleById(ruleId, RuleExecutionRequest.builder()
                .data(inputData)
                .build());
    }

    @Override
    public RuleExecutionResponse executeRuleById(String ruleId, RuleExecutionRequest request) {
        long startTime = System.currentTimeMillis();

        try {
            // Prepare input data
            String inputJson = objectMapper.writeValueAsString(request.getData());
            JsonBuffer inputBuffer = new JsonBuffer(inputJson);

            // Execute the decision using ZenEngine
            CompletableFuture<ZenEngineResponse> futureResponse =
                    zenEngine.evaluate(ruleId, inputBuffer, null);

            ZenEngineResponse response = futureResponse.join();

            // Parse the result
            String resultJson = response.result().toString();
            Map<String, Object> result = objectMapper.readValue(resultJson, Map.class);

            long executionTime = System.currentTimeMillis() - startTime;

            log.info("Rule {} executed successfully in {}ms", ruleId, executionTime);

            return RuleExecutionResponse.builder()
                    .success(true)
                    .result(result)
                    .ruleId(ruleId)
                    .executionTimeMs(executionTime)
                    .build();

        } catch (Exception e) {
            log.error("Error executing rule: {}", ruleId, e);
            long executionTime = System.currentTimeMillis() - startTime;

            return RuleExecutionResponse.builder()
                    .success(false)
                    .error("Failed to execute rule " + ruleId + ": " + e.getMessage())
                    .ruleId(ruleId)
                    .executionTimeMs(executionTime)
                    .build();
        }
    }
}