package com.gorules.library.config;

import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;


public class DynamoDBConfig {

    public static DynamoDbClient createDynamoDbClient(Region region) {
        return DynamoDbClient.builder()
                .region(region)
                .credentialsProvider(DefaultCredentialsProvider.create())
                .build();
    }

    public static DynamoDbClient createDynamoDbClient(String region) {
        return createDynamoDbClient(Region.of(region));
    }
}