package com.gorules.library;

import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Repository for managing rules in DynamoDB
 */
@Slf4j
public class DynamoDBRuleRepository {

    private final DynamoDbClient dynamoDbClient;
    private final String tableName;
    private final String ruleIdAttribute;
    private final String ruleContentAttribute;

    public DynamoDBRuleRepository(DynamoDbClient dynamoDbClient, String tableName) {
        this(dynamoDbClient, tableName, "ruleId", "ruleContent");
    }

    public DynamoDBRuleRepository(DynamoDbClient dynamoDbClient, String tableName,
                                  String ruleIdAttribute, String ruleContentAttribute) {
        this.dynamoDbClient = dynamoDbClient;
        this.tableName = tableName;
        this.ruleIdAttribute = ruleIdAttribute;
        this.ruleContentAttribute = ruleContentAttribute;
    }

    /**
     * Get a rule by its ID from DynamoDB
     */
    public String getRuleById(String ruleId) {
        try {
            GetItemRequest request = GetItemRequest.builder()
                    .tableName(tableName)
                    .key(Map.of(ruleIdAttribute, AttributeValue.builder().s(ruleId).build()))
                    .build();

            GetItemResponse response = dynamoDbClient.getItem(request);

            if (!response.hasItem()) {
                throw new RuntimeException("Rule not found: " + ruleId);
            }

            return response.item().get(ruleContentAttribute).s();
        } catch (Exception e) {
            log.error("Error fetching rule from DynamoDB: {}", ruleId, e);
            throw new RuntimeException("Failed to fetch rule: " + ruleId, e);
        }
    }

    /**
     * Get all rule IDs from DynamoDB
     */
    public List<String> getAllRuleIds() {
        try {
            List<String> ruleIds = new ArrayList<>();

            ScanRequest scanRequest = ScanRequest.builder()
                    .tableName(tableName)
                    .projectionExpression(ruleIdAttribute)
                    .build();

            ScanResponse response = dynamoDbClient.scan(scanRequest);

            for (Map<String, AttributeValue> item : response.items()) {
                String ruleId = item.get(ruleIdAttribute).s();
                ruleIds.add(ruleId);
            }


            while (response.lastEvaluatedKey() != null && !response.lastEvaluatedKey().isEmpty()) {
                scanRequest = ScanRequest.builder()
                        .tableName(tableName)
                        .projectionExpression(ruleIdAttribute)
                        .exclusiveStartKey(response.lastEvaluatedKey())
                        .build();

                response = dynamoDbClient.scan(scanRequest);

                for (Map<String, AttributeValue> item : response.items()) {
                    String ruleId = item.get(ruleIdAttribute).s();
                    ruleIds.add(ruleId);
                }
            }

            return ruleIds;
        } catch (Exception e) {
            log.error("Error fetching all rule IDs from DynamoDB", e);
            throw new RuntimeException("Failed to fetch rule IDs", e);
        }
    }

    /**
     * Save a rule to DynamoDB
     */
    public void saveRule(String ruleId, String ruleContent) {
        try {
            PutItemRequest request = PutItemRequest.builder()
                    .tableName(tableName)
                    .item(Map.of(
                            ruleIdAttribute, AttributeValue.builder().s(ruleId).build(),
                            ruleContentAttribute, AttributeValue.builder().s(ruleContent).build()
                    ))
                    .build();

            dynamoDbClient.putItem(request);
            log.info("Rule saved successfully: {}", ruleId);
        } catch (Exception e) {
            log.error("Error saving rule to DynamoDB: {}", ruleId, e);
            throw new RuntimeException("Failed to save rule: " + ruleId, e);
        }
    }

    /**
     * Delete a rule from DynamoDB
     */
    public void deleteRule(String ruleId) {
        try {
            DeleteItemRequest request = DeleteItemRequest.builder()
                    .tableName(tableName)
                    .key(Map.of(ruleIdAttribute, AttributeValue.builder().s(ruleId).build()))
                    .build();

            dynamoDbClient.deleteItem(request);
            log.info("Rule deleted successfully: {}", ruleId);
        } catch (Exception e) {
            log.error("Error deleting rule from DynamoDB: {}", ruleId, e);
            throw new RuntimeException("Failed to delete rule: " + ruleId, e);
        }
    }
}