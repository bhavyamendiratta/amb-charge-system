package com.gorules.library;

import com.gorules.library.model.RuleExecutionRequest;
import com.gorules.library.model.RuleExecutionResponse;

import java.util.Map;

/**
 * Interface for executing a specific rule by its ID
 */
public interface RuleExecutorById {

    /**
     * Execute a specific rule by its ID from DynamoDB
     *
     * @param ruleId The unique identifier of the rule to execute
     * @param inputData The input data map to evaluate against the rule
     * @return RuleExecutionResponse containing the result
     */
    RuleExecutionResponse executeRuleById(String ruleId, Map<String, Object> inputData);

    /**
     * Execute a specific rule by its ID from DynamoDB
     *
     * @param ruleId The unique identifier of the rule to execute
     * @param request The rule execution request containing input data
     * @return RuleExecutionResponse containing the result
     */
    RuleExecutionResponse executeRuleById(String ruleId, RuleExecutionRequest request);
}