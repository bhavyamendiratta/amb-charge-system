package com.example.gorules.service;

import com.example.gorules.entity.RuleEntity;
import com.example.gorules.model.CreateRuleRequest;
import com.example.gorules.model.RuleResponse;
import com.example.gorules.model.UpdateRuleRequest;
import com.example.gorules.repository.RuleRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class RuleManagementService {

    private final RuleRepository ruleRepository;
    private final ObjectMapper objectMapper;

    public RuleResponse createRule(CreateRuleRequest request) {
        log.info("Creating new rule: {}", request.getRuleId());

        // Validate JSON format
        validateRuleContent(request.getRuleContent());

        if (ruleRepository.exists(request.getRuleId())) {
            throw new IllegalArgumentException("Rule with ID " + request.getRuleId() + " already exists");
        }

        RuleEntity entity = RuleEntity.builder()
                .ruleId(request.getRuleId())
                .ruleName(request.getRuleName())
                .description(request.getDescription())
                .ruleContent(request.getRuleContent())
                .createdBy(request.getCreatedBy())
                .createdAt(Instant.now())
                .updatedAt(Instant.now())
                .status(request.getStatus() != null ? request.getStatus() : "ACTIVE")
                .version(request.getVersion() != null ? request.getVersion() : "1.0")
                .build();

        RuleEntity saved = ruleRepository.save(entity);
        return mapToResponse(saved);
    }

    public RuleResponse updateRule(String ruleId, UpdateRuleRequest request) {
        log.info("Updating rule: {}", ruleId);

        RuleEntity existing = ruleRepository.findById(ruleId)
                .orElseThrow(() -> new IllegalArgumentException("Rule not found: " + ruleId));

        if (request.getRuleName() != null) {
            existing.setRuleName(request.getRuleName());
        }
        if (request.getDescription() != null) {
            existing.setDescription(request.getDescription());
        }
        if (request.getRuleContent() != null) {
            validateRuleContent(request.getRuleContent());
            existing.setRuleContent(request.getRuleContent());
        }
        if (request.getStatus() != null) {
            existing.setStatus(request.getStatus());
        }
        if (request.getVersion() != null) {
            existing.setVersion(request.getVersion());
        }

        existing.setUpdatedAt(Instant.now());

        RuleEntity updated = ruleRepository.save(existing);
        return mapToResponse(updated);
    }

    public RuleResponse getRuleById(String ruleId) {
        log.info("Getting rule by ID: {}", ruleId);

        return ruleRepository.findById(ruleId)
                .map(this::mapToResponse)
                .orElseThrow(() -> new IllegalArgumentException("Rule not found: " + ruleId));
    }

    public List<RuleResponse> getAllRules() {
        log.info("Getting all rules");

        return ruleRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<RuleResponse> getRulesByStatus(String status) {
        log.info("Getting rules by status: {}", status);

        return ruleRepository.findByStatus(status).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public void deleteRule(String ruleId) {
        log.info("Deleting rule: {}", ruleId);

        if (!ruleRepository.exists(ruleId)) {
            throw new IllegalArgumentException("Rule not found: " + ruleId);
        }

        ruleRepository.deleteById(ruleId);
    }

    public String getRuleContent(String ruleId) {
        log.info("Getting rule content for: {}", ruleId);

        return ruleRepository.findById(ruleId)
                .map(RuleEntity::getRuleContent)
                .orElseThrow(() -> new IllegalArgumentException("Rule not found: " + ruleId));
    }

    private void validateRuleContent(String ruleContent) {
        try {
            objectMapper.readTree(ruleContent);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid JSON format for rule content: " + e.getMessage());
        }
    }

    private RuleResponse mapToResponse(RuleEntity entity) {
        return RuleResponse.builder()
                .ruleId(entity.getRuleId())
                .ruleName(entity.getRuleName())
                .description(entity.getDescription())
                .ruleContent(entity.getRuleContent())
                .createdBy(entity.getCreatedBy())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .status(entity.getStatus())
                .version(entity.getVersion())
                .build();
    }
}