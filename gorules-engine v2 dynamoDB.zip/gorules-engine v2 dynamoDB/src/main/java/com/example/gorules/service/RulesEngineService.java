package com.example.gorules.service;

import com.example.gorules.model.RulesRequest;
import com.example.gorules.model.RulesResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.gorules.zen_engine.ZenEngine;
import io.gorules.zen_engine.JsonBuffer;
import io.gorules.zen_engine.ZenDecisionLoaderCallback;
import io.gorules.zen_engine.ZenEngineResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
@RequiredArgsConstructor
public class RulesEngineService {

    private final ObjectMapper objectMapper;
    private final RuleManagementService ruleManagementService;

    /**
     * Execute rules by fetching from DynamoDB using ruleId
     */
    public RulesResponse executeRuleById(String ruleId, RulesRequest request) throws Exception {
        long startTime = System.currentTimeMillis();

        try {
            // Fetch rule content from DynamoDB
            String rulesJson = ruleManagementService.getRuleContent(ruleId);

            // Execute using the fetched rule
            return executeRulesInline(rulesJson, request, startTime);

        } catch (Exception e) {
            log.error("Error executing rules for ruleId: {}", ruleId, e);
            long executionTime = System.currentTimeMillis() - startTime;

            return RulesResponse.builder()
                    .success(false)
                    .error(e.getMessage())
                    .executionTimeMs(executionTime)
                    .build();
        }
    }

    /**
     * Execute rules with inline JSON content
     */
    public RulesResponse executeRulesInline(String rulesJson, RulesRequest request) throws Exception {
        return executeRulesInline(rulesJson, request, System.currentTimeMillis());
    }

    private RulesResponse executeRulesInline(String rulesJson, RulesRequest request, long startTime) throws Exception {
        try {
            // Create a loader callback that returns the rules JSON
            ZenDecisionLoaderCallback loaderCallback = (key) -> {
                return CompletableFuture.completedFuture(new JsonBuffer(rulesJson));
            };

            // Create ZenEngine instance with the loader
            ZenEngine engine = new ZenEngine(loaderCallback, null);

            // Prepare input data
            String inputJson = objectMapper.writeValueAsString(request.getData());
            JsonBuffer inputBuffer = new JsonBuffer(inputJson);

            // Execute the decision
            CompletableFuture<ZenEngineResponse> futureResponse =
                    engine.evaluate("rule", inputBuffer, null);

            ZenEngineResponse response = futureResponse.join();

            // Parse the result
            String resultJson = response.result().toString();
            @SuppressWarnings("unchecked")
            Map<String, Object> result = objectMapper.readValue(resultJson, Map.class);

            long executionTime = System.currentTimeMillis() - startTime;

            log.info("Rules executed successfully in {}ms", executionTime);

            return RulesResponse.builder()
                    .success(true)
                    .result(result)
                    .executionTimeMs(executionTime)
                    .build();

        } catch (Exception e) {
            log.error("Error executing rules", e);
            long executionTime = System.currentTimeMillis() - startTime;

            return RulesResponse.builder()
                    .success(false)
                    .error(e.getMessage())
                    .executionTimeMs(executionTime)
                    .build();
        }
    }
}