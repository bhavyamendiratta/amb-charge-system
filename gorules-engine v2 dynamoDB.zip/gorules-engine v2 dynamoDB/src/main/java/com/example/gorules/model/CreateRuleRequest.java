package com.example.gorules.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateRuleRequest {

    @NotBlank(message = "Rule ID is required")
    private String ruleId;

    @NotBlank(message = "Rule name is required")
    private String ruleName;

    private String description;

    @NotBlank(message = "Rule content is required")
    private String ruleContent;

    private String createdBy;
    private String status;
    private String version;
}