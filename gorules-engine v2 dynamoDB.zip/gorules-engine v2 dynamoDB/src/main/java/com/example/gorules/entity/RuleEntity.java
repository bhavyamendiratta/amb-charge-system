package com.example.gorules.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamoDbBean
public class RuleEntity {

    private String ruleId;
    private String ruleName;
    private String description;
    private String ruleContent;
    private String createdBy;
    private Instant createdAt;
    private Instant updatedAt;
    private String status;
    private String version;

    @DynamoDbPartitionKey
    public String getRuleId() {
        return ruleId;
    }
}