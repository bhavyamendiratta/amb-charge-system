package com.example.gorules.controller;

import com.example.gorules.model.CreateRuleRequest;
import com.example.gorules.model.RuleResponse;
import com.example.gorules.model.UpdateRuleRequest;
import com.example.gorules.service.RuleManagementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/rules/management")
@RequiredArgsConstructor
public class RuleManagementController {

    private final RuleManagementService ruleManagementService;

    /**
     * Create a new rule
     */
    @PostMapping
    public ResponseEntity<RuleResponse> createRule(@Valid @RequestBody CreateRuleRequest request) {
        try {
            RuleResponse response = ruleManagementService.createRule(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Get all rules
     */
    @GetMapping
    public ResponseEntity<List<RuleResponse>> getAllRules() {
        List<RuleResponse> rules = ruleManagementService.getAllRules();
        return ResponseEntity.ok(rules);
    }

    /**
     * Get rule by ID
     */
    @GetMapping("/{ruleId}")
    public ResponseEntity<RuleResponse> getRuleById(@PathVariable String ruleId) {
        try {
            RuleResponse response = ruleManagementService.getRuleById(ruleId);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Get rules by status
     */
    @GetMapping("/status/{status}")
    public ResponseEntity<List<RuleResponse>> getRulesByStatus(@PathVariable String status) {
        List<RuleResponse> rules = ruleManagementService.getRulesByStatus(status);
        return ResponseEntity.ok(rules);
    }

    /**
     * Update a rule
     */
    @PutMapping("/{ruleId}")
    public ResponseEntity<RuleResponse> updateRule(
            @PathVariable String ruleId,
            @RequestBody UpdateRuleRequest request) {
        try {
            RuleResponse response = ruleManagementService.updateRule(ruleId, request);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Delete a rule
     */
    @DeleteMapping("/{ruleId}")
    public ResponseEntity<Map<String, String>> deleteRule(@PathVariable String ruleId) {
        try {
            ruleManagementService.deleteRule(ruleId);
            return ResponseEntity.ok(Map.of(
                    "message", "Rule deleted successfully",
                    "ruleId", ruleId
            ));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Get rule content only (JSON)
     */
    @GetMapping("/{ruleId}/content")
    public ResponseEntity<String> getRuleContent(@PathVariable String ruleId) {
        try {
            String content = ruleManagementService.getRuleContent(ruleId);
            return ResponseEntity.ok(content);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }
}