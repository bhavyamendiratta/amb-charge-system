package com.example.gorules.repository;

import com.example.gorules.entity.RuleEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.PageIterable;
import software.amazon.awssdk.enhanced.dynamodb.model.ScanEnhancedRequest;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
@RequiredArgsConstructor
@Slf4j
public class RuleRepository {

    private final DynamoDbTable<RuleEntity> ruleTable;

    public RuleEntity save(RuleEntity rule) {
        log.info("Saving rule with ID: {}", rule.getRuleId());
        ruleTable.putItem(rule);
        return rule;
    }

    public Optional<RuleEntity> findById(String ruleId) {
        log.info("Finding rule by ID: {}", ruleId);
        Key key = Key.builder()
                .partitionValue(ruleId)
                .build();
        RuleEntity rule = ruleTable.getItem(key);
        return Optional.ofNullable(rule);
    }

    public List<RuleEntity> findAll() {
        log.info("Finding all rules");
        PageIterable<RuleEntity> results = ruleTable.scan(ScanEnhancedRequest.builder().build());
        return results.items().stream().collect(Collectors.toList());
    }

    public List<RuleEntity> findByStatus(String status) {
        log.info("Finding rules by status: {}", status);
        return findAll().stream()
                .filter(rule -> status.equals(rule.getStatus()))
                .collect(Collectors.toList());
    }

    public void deleteById(String ruleId) {
        log.info("Deleting rule with ID: {}", ruleId);
        Key key = Key.builder()
                .partitionValue(ruleId)
                .build();
        ruleTable.deleteItem(key);
    }

    public boolean exists(String ruleId) {
        return findById(ruleId).isPresent();
    }
}