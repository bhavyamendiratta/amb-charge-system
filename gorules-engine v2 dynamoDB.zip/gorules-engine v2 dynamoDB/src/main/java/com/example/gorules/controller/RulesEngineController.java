package com.example.gorules.controller;

import com.example.gorules.model.RulesRequest;
import com.example.gorules.model.RulesResponse;
import com.example.gorules.service.RulesEngineService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/rules")
@RequiredArgsConstructor
public class RulesEngineController {

    private final RulesEngineService rulesEngineService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Execute rules by ruleId from DynamoDB
     */
    @PostMapping("/execute/{ruleId}")
    public ResponseEntity<RulesResponse> executeRuleById(
            @PathVariable String ruleId,
            @RequestBody RulesRequest request) {
        try {
            RulesResponse response = rulesEngineService.executeRuleById(ruleId, request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(RulesResponse.builder()
                            .success(false)
                            .error(e.getMessage())
                            .build());
        }
    }

    /**
     * Execute rules with JSON content in request body (original method)
     */
    @PostMapping("/execute-inline")
    public ResponseEntity<RulesResponse> executeRulesInline(
            @RequestBody Map<String, Object> requestBody) {
        try {
            String rulesJson = (String) requestBody.get("rules");
            @SuppressWarnings("unchecked")
            Map<String, Object> inputData = (Map<String, Object>) requestBody.get("data");

            if (rulesJson == null || inputData == null) {
                return ResponseEntity.badRequest()
                        .body(RulesResponse.builder()
                                .success(false)
                                .error("Both 'rules' and 'data' fields are required")
                                .build());
            }

            RulesRequest request = RulesRequest.builder()
                    .data(inputData)
                    .build();

            RulesResponse response = rulesEngineService.executeRulesInline(rulesJson, request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(RulesResponse.builder()
                            .success(false)
                            .error(e.getMessage())
                            .build());
        }
    }

    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status", "UP",
                "service", "GoRules Engine with DynamoDB",
                "version", "2.0.0"
        ));
    }
}