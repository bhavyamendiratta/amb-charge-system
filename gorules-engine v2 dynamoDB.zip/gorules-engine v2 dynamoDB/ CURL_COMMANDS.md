# GoRules Engine with DynamoDB - API Examples

## Rule Management APIs

### 1. Create a Rule
```bash
curl -X POST http://localhost:8080/api/rules/management \
  -H "Content-Type: application/json" \
  -d '{
    "ruleId": "loan-eligibility-v1",
    "ruleName": "Loan Eligibility Rules",
    "description": "Determines loan eligibility based on income, credit score, age etc",
    "createdBy": "admin",
    "status": "ACTIVE",
    "version": "1.0",
    "ruleContent": "{\"contentType\":\"application/vnd.gorules.decision\",\"nodes\":[{\"id\":\"input\",\"name\":\"Input\",\"type\":\"inputNode\",\"content\":{\"fields\":[{\"field\":\"income\",\"name\":\"Income\"},{\"field\":\"tier\",\"name\":\"Tier\"}]}},{\"id\":\"decision\",\"name\":\"Discount Decision\",\"type\":\"decisionTableNode\",\"content\":{\"hitPolicy\":\"first\",\"inputs\":[{\"id\":\"i1\",\"field\":\"income\",\"name\":\"Income\"},{\"id\":\"i2\",\"field\":\"tier\",\"name\":\"Tier\"}],\"outputs\":[{\"id\":\"o1\",\"field\":\"discount\",\"name\":\"Discount\"}],\"rules\":[{\"_id\":\"r1\",\"i1\":\">= 5000\",\"i2\":\"== \\\"gold\\\"\",\"o1\":\"15\"},{\"_id\":\"r2\",\"i1\":\">= 3000\",\"i2\":\"== \\\"silver\\\"\",\"o1\":\"10\"},{\"_id\":\"r3\",\"i1\":\">= 1000\",\"i2\":\"== \\\"bronze\\\"\",\"o1\":\"5\"},{\"_id\":\"r4\",\"i1\":\"\",\"i2\":\"\",\"o1\":\"0\"}]}},{\"id\":\"output\",\"name\":\"Output\",\"type\":\"outputNode\",\"content\":{\"fields\":[{\"field\":\"discount\",\"name\":\"Discount\"}]}}],\"edges\":[{\"id\":\"e1\",\"sourceId\":\"input\",\"targetId\":\"decision\"},{\"id\":\"e2\",\"sourceId\":\"decision\",\"targetId\":\"output\"}]}"
  }'
```

### 2. Get All Rules
```bash
curl -X GET http://localhost:8080/api/rules/management
```

### 3. Get Rule by ID
```bash
curl -X GET http://localhost:8080/api/rules/management/loan-eligibility-v1
```

### 4. Get Rules by Status
```bash
curl -X GET http://localhost:8080/api/rules/management/status/ACTIVE
```

### 5. Update a Rule
```bash
curl -X PUT http://localhost:8080/api/rules/management/loan-eligibility-v1 \
  -H "Content-Type: application/json" \
  -d '{
    "ruleName": "Updated Loan Eligibility Rules",
    "description": "Updated description",
    "status": "ACTIVE",
    "version": "1.1"
  }'
```

### 6. Delete a Rule
```bash
curl -X DELETE http://localhost:8080/api/rules/management/loan-eligibility-v1
```

### 7. Get Rule Content Only
```bash
curl -X GET http://localhost:8080/api/rules/management/loan-eligibility-v1/content
```

## Rule Execution APIs

### 1. Execute Rule by ID (from DynamoDB)
```bash
curl -X POST http://localhost:8080/api/rules/execute/loan-eligibility-v1 \
  -H "Content-Type: application/json" \
  -d '{
    "data": {
      "income": 5500,
      "tier": "gold"
    }
  }'
```

### 2. Execute with Inline Rules (original method)
```bash
curl -X POST http://localhost:8080/api/rules/execute-inline \
  -H "Content-Type: application/json" \
  -d '{
    "rules": "{\"contentType\":\"application/vnd.gorules.decision\",\"nodes\":[...]}",
    "data": {
      "income": 5500,
      "tier": "gold"
    }
  }'
```

## Health Check
```bash
curl -X GET http://localhost:8080/api/rules/health
```