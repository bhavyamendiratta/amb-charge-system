#!/bin/bash
docker run -d -p 8000:8000 amazon/dynamodb-local

docker ps

# For local DynamoDB
aws dynamodb create-table \
    --table-name gorules-rules \
    --attribute-definitions \
        AttributeName=ruleId,AttributeType=S \
    --key-schema \
        AttributeName=ruleId,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST \
    --endpoint-url http://localhost:8000 \
    --region us-east-1

aws dynamodb list-tables --endpoint-url http://localhost:8000 --region us-east-1

mvn clean install
mvn spring-boot:run

# For AWS DynamoDB (production)
# Remove --endpoint-url parameter