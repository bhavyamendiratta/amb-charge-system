package com.ruleengine.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.Map;

/**
 * Request to test a rule with input data
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TestRuleRequest {

    @NotBlank(message = "Rule ID is required")
    private String ruleId;

    @NotNull(message = "Input data is required")
    private Map<String, Object> inputData;

    private Map<String, String> options;

    public TestRuleRequest() {}

    public TestRuleRequest(String ruleId, Map<String, Object> inputData) {
        this.ruleId = ruleId;
        this.inputData = inputData;
    }

    // Getters and Setters
    public String getRuleId() { return ruleId; }
    public void setRuleId(String ruleId) { this.ruleId = ruleId; }

    public Map<String, Object> getInputData() { return inputData; }
    public void setInputData(Map<String, Object> inputData) { this.inputData = inputData; }

    public Map<String, String> getOptions() { return options; }
    public void setOptions(Map<String, String> options) { this.options = options; }
}