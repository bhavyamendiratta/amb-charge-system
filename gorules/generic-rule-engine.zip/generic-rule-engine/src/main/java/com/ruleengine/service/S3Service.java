package com.ruleengine.service;

import com.ruleengine.model.RuleMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Service for S3 operations
 */
@Service
public class S3Service {

    private static final Logger log = LoggerFactory.getLogger(S3Service.class);

    private final S3Client s3Client;

    @Value("${aws.s3.bucket-name}")
    private String bucketName;

    public S3Service(S3Client s3Client) {
        this.s3Client = s3Client;
    }

    /**
     * Upload rule to S3
     */
    public void uploadRule(String s3Key, String ruleContent, Map<String, String> metadata) {
        try {
            PutObjectRequest.Builder requestBuilder = PutObjectRequest.builder()
                    .bucket(bucketName)
                    .key(s3Key)
                    .contentType("application/json");

            // Add metadata if provided
            if (metadata != null && !metadata.isEmpty()) {
                requestBuilder.metadata(metadata);
            }

            s3Client.putObject(requestBuilder.build(),
                    RequestBody.fromString(ruleContent, StandardCharsets.UTF_8));

            log.info("✓ Uploaded rule to S3: {}", s3Key);
        } catch (Exception e) {
            log.error("Failed to upload rule to S3: {}", s3Key, e);
            throw new RuntimeException("Failed to upload rule to S3", e);
        }
    }

    /**
     * Download rule from S3
     */
    public String downloadRule(String s3Key) {
        try {
            GetObjectRequest request = GetObjectRequest.builder()
                    .bucket(bucketName)
                    .key(s3Key)
                    .build();

            String content = s3Client.getObjectAsBytes(request).asUtf8String();
            log.debug("Downloaded rule from S3: {} ({} bytes)", s3Key, content.length());
            return content;
        } catch (NoSuchKeyException e) {
            log.error("Rule not found in S3: {}", s3Key);
            throw new RuntimeException("Rule not found: " + s3Key, e);
        } catch (Exception e) {
            log.error("Failed to download rule from S3: {}", s3Key, e);
            throw new RuntimeException("Failed to download rule from S3", e);
        }
    }

    /**
     * Delete rule from S3
     */
    public void deleteRule(String s3Key) {
        try {
            DeleteObjectRequest request = DeleteObjectRequest.builder()
                    .bucket(bucketName)
                    .key(s3Key)
                    .build();

            s3Client.deleteObject(request);
            log.info("✓ Deleted rule from S3: {}", s3Key);
        } catch (Exception e) {
            log.error("Failed to delete rule from S3: {}", s3Key, e);
            throw new RuntimeException("Failed to delete rule from S3", e);
        }
    }

    /**
     * List all rules in S3 bucket
     */
    public List<RuleMetadata> listRules(String prefix) {
        List<RuleMetadata> rules = new ArrayList<>();

        try {
            ListObjectsV2Request.Builder requestBuilder = ListObjectsV2Request.builder()
                    .bucket(bucketName);

            if (prefix != null && !prefix.isEmpty()) {
                requestBuilder.prefix(prefix);
            }

            ListObjectsV2Response response = s3Client.listObjectsV2(requestBuilder.build());

            for (S3Object s3Object : response.contents()) {
                RuleMetadata metadata = new RuleMetadata();
                metadata.setS3Key(s3Object.key());
                metadata.setRuleId(extractRuleId(s3Object.key()));
                metadata.setLastModified(LocalDateTime.ofInstant(
                        s3Object.lastModified(), ZoneId.systemDefault()));
                metadata.setSizeBytes(s3Object.size());
                metadata.setEtag(s3Object.eTag());
                rules.add(metadata);
            }

            log.debug("Listed {} rules from S3", rules.size());
        } catch (Exception e) {
            log.error("Failed to list rules from S3", e);
            throw new RuntimeException("Failed to list rules from S3", e);
        }

        return rules;
    }

    /**
     * Check if rule exists in S3
     */
    public boolean ruleExists(String s3Key) {
        try {
            HeadObjectRequest request = HeadObjectRequest.builder()
                    .bucket(bucketName)
                    .key(s3Key)
                    .build();

            s3Client.headObject(request);
            return true;
        } catch (NoSuchKeyException e) {
            return false;
        } catch (Exception e) {
            log.error("Error checking if rule exists: {}", s3Key, e);
            return false;
        }
    }

    /**
     * Get rule metadata from S3
     */
    public RuleMetadata getRuleMetadata(String s3Key) {
        try {
            HeadObjectRequest request = HeadObjectRequest.builder()
                    .bucket(bucketName)
                    .key(s3Key)
                    .build();

            HeadObjectResponse response = s3Client.headObject(request);

            RuleMetadata metadata = new RuleMetadata();
            metadata.setS3Key(s3Key);
            metadata.setRuleId(extractRuleId(s3Key));
            metadata.setLastModified(LocalDateTime.ofInstant(
                    response.lastModified(), ZoneId.systemDefault()));
            metadata.setSizeBytes(response.contentLength());
            metadata.setEtag(response.eTag());

            if (response.metadata() != null) {
                metadata.setTags(response.metadata());
            }

            return metadata;
        } catch (Exception e) {
            log.error("Failed to get rule metadata: {}", s3Key, e);
            throw new RuntimeException("Failed to get rule metadata", e);
        }
    }

    /**
     * Extract rule ID from S3 key
     */
    private String extractRuleId(String s3Key) {
        // Remove .json extension and path prefix
        String fileName = s3Key.substring(s3Key.lastIndexOf('/') + 1);
        return fileName.replace(".json", "");
    }
}