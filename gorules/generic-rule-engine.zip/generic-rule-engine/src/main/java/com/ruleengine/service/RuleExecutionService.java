package com.ruleengine.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.gorules.zen_engine.JsonBuffer;
import io.gorules.zen_engine.ZenEngine;
import io.gorules.zen_engine.ZenEngineResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * Rule Execution Service
 * Handles rule evaluation using GoRules Zen Engine
 */
@Service
public class RuleExecutionService {

    private static final Logger log = LoggerFactory.getLogger(RuleExecutionService.class);

    private final ZenEngine zenEngine;
    private final RuleStorageService ruleStorageService;
    private final ObjectMapper objectMapper;

    public RuleExecutionService(ZenEngine zenEngine,
                                RuleStorageService ruleStorageService,
                                ObjectMapper objectMapper) {
        this.zenEngine = zenEngine;
        this.ruleStorageService = ruleStorageService;
        this.objectMapper = objectMapper;
    }

    /**
     * Execute a rule with given input data
     */
    public Map<String, Object> executeRule(String ruleId, Map<String, Object> inputData) {
        try {
            log.debug("Executing rule: {} with input: {}", ruleId, inputData);

            // Ensure rule is loaded in cache
            String ruleContent = ruleStorageService.getRuleContent(ruleId);
            if (ruleContent == null) {
                throw new RuntimeException("Rule not found: " + ruleId);
            }

            // Convert input to JSON
            String inputJson = objectMapper.writeValueAsString(inputData);
            JsonBuffer inputBuffer = new JsonBuffer(inputJson);

            // Execute rule
            CompletableFuture<ZenEngineResponse> futureResponse =
                    zenEngine.evaluate(ruleId, inputBuffer, null);

            ZenEngineResponse response = futureResponse.join();

            // Parse result
            String resultJson = response.result().toString();
            @SuppressWarnings("unchecked")
            Map<String, Object> result = objectMapper.readValue(resultJson, Map.class);

            log.debug("Rule execution result: {}", result);
            return result;

        } catch (Exception e) {
            log.error("Failed to execute rule: {}", ruleId, e);
            throw new RuntimeException("Failed to execute rule: " + ruleId, e);
        }
    }

    /**
     * Execute rule with trace information
     */
    public Map<String, Object> executeRuleWithTrace(String ruleId, Map<String, Object> inputData) {
        try {
            log.debug("Executing rule with trace: {}", ruleId);

            String ruleContent = ruleStorageService.getRuleContent(ruleId);
            if (ruleContent == null) {
                throw new RuntimeException("Rule not found: " + ruleId);
            }

            String inputJson = objectMapper.writeValueAsString(inputData);
            JsonBuffer inputBuffer = new JsonBuffer(inputJson);

            CompletableFuture<ZenEngineResponse> futureResponse =
                    zenEngine.evaluate(ruleId, inputBuffer, null);

            ZenEngineResponse response = futureResponse.join();

            // Parse result and trace
            String resultJson = response.result().toString();
            String traceJson = response.trace() != null ? response.trace().toString() : "{}";

            @SuppressWarnings("unchecked")
            Map<String, Object> result = objectMapper.readValue(resultJson, Map.class);
            @SuppressWarnings("unchecked")
            Map<String, Object> trace = objectMapper.readValue(traceJson, Map.class);

            // Combine result and trace
            Map<String, Object> combined = new java.util.HashMap<>(result);
            combined.put("_trace", trace);
            combined.put("_performance", response.performance());

            return combined;

        } catch (Exception e) {
            log.error("Failed to execute rule with trace: {}", ruleId, e);
            throw new RuntimeException("Failed to execute rule with trace", e);
        }
    }

    /**
     * Test rule without persisting - FIXED VERSION
     * This now properly uses the rule content from the existing rule
     */
    public Map<String, Object> testRule(String ruleContent, Map<String, Object> inputData) {
        try {
            log.debug("Testing rule with input: {}", inputData);

            // Parse the rule content to get the rule ID
            @SuppressWarnings("unchecked")
            Map<String, Object> ruleJson = objectMapper.readValue(ruleContent, Map.class);

            // Extract rule ID from content or use a temporary one
            String ruleId = ruleJson.containsKey("id")
                    ? ruleJson.get("id").toString()
                    : "temp-test-rule";

            // Create a temporary ZenEngine instance for testing
            // OR use the existing rule if it's already loaded
            String inputJson = objectMapper.writeValueAsString(inputData);
            JsonBuffer inputBuffer = new JsonBuffer(inputJson);

            // If the rule is already in storage, use it directly
            CompletableFuture<ZenEngineResponse> futureResponse =
                    zenEngine.evaluate(ruleId, inputBuffer, null);

            ZenEngineResponse response = futureResponse.join();

            // Parse result
            String resultJson = response.result().toString();
            @SuppressWarnings("unchecked")
            Map<String, Object> result = objectMapper.readValue(resultJson, Map.class);

            log.debug("Test rule execution result: {}", result);
            return result;

        } catch (Exception e) {
            log.error("Failed to test rule", e);
            throw new RuntimeException("Failed to test rule: " + e.getMessage(), e);
        }
    }
}