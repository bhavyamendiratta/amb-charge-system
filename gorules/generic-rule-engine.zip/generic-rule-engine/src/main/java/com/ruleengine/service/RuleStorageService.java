package com.ruleengine.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ruleengine.model.RuleMetadata;
import com.ruleengine.model.RuleRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Rule Storage Service with hot-reload capability
 * Manages rules in-memory with periodic S3 synchronization
 */
@Service
public class RuleStorageService {

    private static final Logger log = LoggerFactory.getLogger(RuleStorageService.class);

    private final S3Service s3Service;
    private final ObjectMapper objectMapper;

    @Value("${aws.s3.bucket-name}")
    private String bucketName;

    @Value("${rule-engine.hot-reload.enabled:true}")
    private boolean hotReloadEnabled;

    @Value("${rule-engine.cache.max-size:100}")
    private int cacheMaxSize;

    // In-memory cache: ruleId -> ruleContent
    private final Map<String, String> ruleCache = new ConcurrentHashMap<>();

    // Metadata cache: ruleId -> RuleMetadata
    private final Map<String, RuleMetadata> metadataCache = new ConcurrentHashMap<>();

    // ETag tracking for change detection
    private final Map<String, String> etagMap = new ConcurrentHashMap<>();

    public RuleStorageService(S3Service s3Service, ObjectMapper objectMapper) {
        this.s3Service = s3Service;
        this.objectMapper = objectMapper;
    }

    /**
     * Initialize - Load all rules from S3 on startup
     */
    public void initialize() {
        log.info("🚀 Initializing Rule Storage Service...");
        reloadAllRules();
        log.info("✓ Rule Storage Service initialized with {} rules", ruleCache.size());
    }

    /**
     * Get rule content by rule ID
     */
    public String getRuleContent(String ruleId) {
        // Check cache first
        String content = ruleCache.get(ruleId);

        if (content == null) {
            // Cache miss - load from S3
            log.info("Cache miss for rule: {}. Loading from S3...", ruleId);
            content = loadRuleFromS3(ruleId);

            if (content != null) {
                ruleCache.put(ruleId, content);
            }
        }

        return content;
    }

    /**
     * Create or update a rule
     */
    public RuleMetadata createOrUpdateRule(RuleRequest request) {
        try {
            String ruleId = request.getRuleId();
            String s3Key = buildS3Key(ruleId);

            // Convert rule content to JSON string
            String ruleContent = objectMapper.writeValueAsString(request.getRuleContent());

            // Prepare metadata
            Map<String, String> s3Metadata = new HashMap<>();
            s3Metadata.put("ruleName", request.getRuleName());
            s3Metadata.put("description", request.getDescription() != null ? request.getDescription() : "");
            s3Metadata.put("active", String.valueOf(request.isActive()));

            // Upload to S3
            s3Service.uploadRule(s3Key, ruleContent, s3Metadata);

            // Update cache
            ruleCache.put(ruleId, ruleContent);

            // Build metadata response
            RuleMetadata metadata = new RuleMetadata(ruleId, request.getRuleName());
            metadata.setDescription(request.getDescription());
            metadata.setS3Key(s3Key);
            metadata.setActive(request.isActive());
            metadata.setLastModified(LocalDateTime.now());
            metadata.setLastLoaded(LocalDateTime.now());
            metadata.setTags(request.getTags());

            metadataCache.put(ruleId, metadata);

            log.info("✓ Rule created/updated: {}", ruleId);
            return metadata;

        } catch (Exception e) {
            log.error("Failed to create/update rule: {}", request.getRuleId(), e);
            throw new RuntimeException("Failed to create/update rule", e);
        }
    }

    /**
     * Delete a rule
     */
    public void deleteRule(String ruleId) {
        String s3Key = buildS3Key(ruleId);

        // Delete from S3
        s3Service.deleteRule(s3Key);

        // Remove from cache
        ruleCache.remove(ruleId);
        metadataCache.remove(ruleId);
        etagMap.remove(ruleId);

        log.info("✓ Rule deleted: {}", ruleId);
    }

    /**
     * Get rule metadata
     */
    public RuleMetadata getRuleMetadata(String ruleId) {
        // Check cache first
        RuleMetadata metadata = metadataCache.get(ruleId);

        if (metadata == null) {
            // Load from S3
            String s3Key = buildS3Key(ruleId);
            metadata = s3Service.getRuleMetadata(s3Key);
            metadataCache.put(ruleId, metadata);
        }

        return metadata;
    }

    /**
     * List all rules
     */
    public List<RuleMetadata> listAllRules() {
        List<RuleMetadata> s3Rules = s3Service.listRules("");

        // Enrich with cached metadata
        for (RuleMetadata metadata : s3Rules) {
            RuleMetadata cached = metadataCache.get(metadata.getRuleId());
            if (cached != null) {
                metadata.setLastLoaded(cached.getLastLoaded());
                metadata.setActive(cached.isActive());
            }
        }

        return s3Rules;
    }

    /**
     * HOT RELOAD: Scheduled task to reload rules from S3
     * Runs every 30 seconds by default (configurable via application.yml)
     */
    @Scheduled(fixedDelayString = "${rule-engine.hot-reload.interval-seconds:30}000")
    public void hotReloadRules() {
        if (!hotReloadEnabled) {
            return;
        }

        log.debug("🔄 Hot reload: Checking for rule updates...");

        try {
            List<RuleMetadata> s3Rules = s3Service.listRules("");
            int reloadedCount = 0;

            for (RuleMetadata s3Metadata : s3Rules) {
                String ruleId = s3Metadata.getRuleId();
                String currentEtag = etagMap.get(ruleId);
                String newEtag = s3Metadata.getEtag();

                // Check if rule changed (ETag mismatch) or new rule
                if (currentEtag == null || !currentEtag.equals(newEtag)) {
                    log.info("🔄 Reloading rule: {} (ETag changed)", ruleId);

                    String content = loadRuleFromS3(ruleId);
                    if (content != null) {
                        ruleCache.put(ruleId, content);
                        etagMap.put(ruleId, newEtag);

                        s3Metadata.setLastLoaded(LocalDateTime.now());
                        metadataCache.put(ruleId, s3Metadata);

                        reloadedCount++;
                    }
                }
            }

            if (reloadedCount > 0) {
                log.info("✓ Hot reload complete: {} rules updated", reloadedCount);
            }

        } catch (Exception e) {
            log.error("Hot reload failed", e);
        }
    }

    /**
     * Force reload all rules from S3
     */
    public void reloadAllRules() {
        log.info("🔄 Force reloading all rules from S3...");

        try {
            List<RuleMetadata> s3Rules = s3Service.listRules("");

            for (RuleMetadata metadata : s3Rules) {
                String ruleId = metadata.getRuleId();
                String content = loadRuleFromS3(ruleId);

                if (content != null) {
                    ruleCache.put(ruleId, content);
                    etagMap.put(ruleId, metadata.getEtag());

                    metadata.setLastLoaded(LocalDateTime.now());
                    metadataCache.put(ruleId, metadata);
                }
            }

            log.info("✓ Reloaded {} rules", ruleCache.size());
        } catch (Exception e) {
            log.error("Failed to reload all rules", e);
            throw new RuntimeException("Failed to reload rules", e);
        }
    }

    /**
     * Clear cache
     */
    public void clearCache() {
        ruleCache.clear();
        metadataCache.clear();
        etagMap.clear();
        log.info("✓ Cache cleared");
    }

    /**
     * Get cache statistics
     */
    public Map<String, Object> getCacheStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("cachedRules", ruleCache.size());
        stats.put("metadataCached", metadataCache.size());
        stats.put("maxCacheSize", cacheMaxSize);
        stats.put("hotReloadEnabled", hotReloadEnabled);
        return stats;
    }

    /**
     * Load rule content from S3
     */
    private String loadRuleFromS3(String ruleId) {
        try {
            String s3Key = buildS3Key(ruleId);
            return s3Service.downloadRule(s3Key);
        } catch (Exception e) {
            log.error("Failed to load rule from S3: {}", ruleId, e);
            return null;
        }
    }

    /**
     * Build S3 key from rule ID
     */
    private String buildS3Key(String ruleId) {
        return ruleId.endsWith(".json") ? ruleId : ruleId + ".json";
    }
}