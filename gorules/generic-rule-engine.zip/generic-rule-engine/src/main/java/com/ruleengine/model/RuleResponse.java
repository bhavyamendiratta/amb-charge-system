package com.ruleengine.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * Generic response wrapper for rule operations
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RuleResponse {

    private boolean success;
    private String message;
    private Map<String, Object> data;
    private Map<String, Object> result;
    private RuleMetadata metadata;
    private LocalDateTime timestamp;
    private String error;

    public RuleResponse() {
        this.timestamp = LocalDateTime.now();
    }

    public static RuleResponse success(String message) {
        RuleResponse response = new RuleResponse();
        response.setSuccess(true);
        response.setMessage(message);
        return response;
    }

    public static RuleResponse success(String message, Map<String, Object> data) {
        RuleResponse response = success(message);
        response.setData(data);
        return response;
    }

    public static RuleResponse error(String message, String error) {
        RuleResponse response = new RuleResponse();
        response.setSuccess(false);
        response.setMessage(message);
        response.setError(error);
        return response;
    }

    // Getters and Setters
    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public Map<String, Object> getData() { return data; }
    public void setData(Map<String, Object> data) { this.data = data; }

    public Map<String, Object> getResult() { return result; }
    public void setResult(Map<String, Object> result) { this.result = result; }

    public RuleMetadata getMetadata() { return metadata; }
    public void setMetadata(RuleMetadata metadata) { this.metadata = metadata; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public String getError() { return error; }
    public void setError(String error) { this.error = error; }
}