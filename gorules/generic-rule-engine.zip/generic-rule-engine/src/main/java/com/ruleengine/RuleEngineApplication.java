package com.ruleengine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Generic Rule Engine Application
 *
 * Features:
 * - Hot reload rules from S3
 * - REST APIs for CRUD operations
 * - Rule testing endpoint
 * - Multi-tenant support
 */
@SpringBootApplication
@EnableScheduling
public class RuleEngineApplication {

    public static void main(String[] args) {
        SpringApplication.run(RuleEngineApplication.class, args);
        System.out.println("\n" +
                "╔═══════════════════════════════════════════════════════════╗\n" +
                "║     Generic Rule Engine Service Started Successfully     ║\n" +
                "║                                                           ║\n" +
                "║  Swagger UI: http://localhost:8080/swagger-ui.html       ║\n" +
                "║  Health: http://localhost:8080/actuator/health           ║\n" +
                "╚═══════════════════════════════════════════════════════════╝\n");
    }
}