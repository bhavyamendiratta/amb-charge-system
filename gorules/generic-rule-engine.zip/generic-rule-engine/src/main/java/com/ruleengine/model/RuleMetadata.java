package com.ruleengine.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * Metadata about a rule stored in S3
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RuleMetadata {

    private String ruleId;
    private String ruleName;
    private String description;
    private String s3Key;
    private String version;
    private LocalDateTime lastModified;
    private LocalDateTime lastLoaded;
    private Long sizeBytes;
    private String etag;
    private Map<String, String> tags;
    private boolean active;

    public RuleMetadata() {}

    public RuleMetadata(String ruleId, String ruleName) {
        this.ruleId = ruleId;
        this.ruleName = ruleName;
        this.active = true;
    }

    // Getters and Setters
    public String getRuleId() { return ruleId; }
    public void setRuleId(String ruleId) { this.ruleId = ruleId; }

    public String getRuleName() { return ruleName; }
    public void setRuleName(String ruleName) { this.ruleName = ruleName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getS3Key() { return s3Key; }
    public void setS3Key(String s3Key) { this.s3Key = s3Key; }

    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }

    public LocalDateTime getLastModified() { return lastModified; }
    public void setLastModified(LocalDateTime lastModified) { this.lastModified = lastModified; }

    public LocalDateTime getLastLoaded() { return lastLoaded; }
    public void setLastLoaded(LocalDateTime lastLoaded) { this.lastLoaded = lastLoaded; }

    public Long getSizeBytes() { return sizeBytes; }
    public void setSizeBytes(Long sizeBytes) { this.sizeBytes = sizeBytes; }

    public String getEtag() { return etag; }
    public void setEtag(String etag) { this.etag = etag; }

    public Map<String, String> getTags() { return tags; }
    public void setTags(Map<String, String> tags) { this.tags = tags; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}