package com.ruleengine.config;

import io.gorules.zen_engine.ZenEngine;
import io.gorules.zen_engine.ZenDecisionLoaderCallback;
import io.gorules.zen_engine.JsonBuffer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import com.ruleengine.service.RuleStorageService;

import java.util.concurrent.CompletableFuture;

/**
 * GoRules Zen Engine Configuration
 *
 * Note: Uses @Lazy to avoid circular dependency issues during bean initialization
 */
@Configuration
public class ZenEngineConfig {

    @Bean
    public ZenEngine zenEngine(@Lazy RuleStorageService ruleStorageService) {

        // Dynamic loader callback that fetches rules from storage
        ZenDecisionLoaderCallback loaderCallback = (key) -> {
            try {
                String ruleContent = ruleStorageService.getRuleContent(key);
                if (ruleContent == null) {
                    return CompletableFuture.failedFuture(
                            new RuntimeException("Rule not found: " + key)
                    );
                }
                return CompletableFuture.completedFuture(new JsonBuffer(ruleContent));
            } catch (Exception e) {
                return CompletableFuture.failedFuture(e);
            }
        };

        ZenEngine engine = new ZenEngine(loaderCallback, null);
        System.out.println("✓ Zen Engine initialized with dynamic rule loader");
        return engine;
    }
}