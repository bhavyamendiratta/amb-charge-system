package com.ruleengine.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.Map;

/**
 * Request to create or update a rule
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RuleRequest {

    @NotBlank(message = "Rule ID is required")
    private String ruleId;

    @NotBlank(message = "Rule name is required")
    private String ruleName;

    private String description;

    @NotNull(message = "Rule content is required")
    private Map<String, Object> ruleContent;

    private Map<String, String> tags;

    private boolean active = true;

    public RuleRequest() {}

    // Getters and Setters
    public String getRuleId() { return ruleId; }
    public void setRuleId(String ruleId) { this.ruleId = ruleId; }

    public String getRuleName() { return ruleName; }
    public void setRuleName(String ruleName) { this.ruleName = ruleName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Map<String, Object> getRuleContent() { return ruleContent; }
    public void setRuleContent(Map<String, Object> ruleContent) { this.ruleContent = ruleContent; }

    public Map<String, String> getTags() { return tags; }
    public void setTags(Map<String, String> tags) { this.tags = tags; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}