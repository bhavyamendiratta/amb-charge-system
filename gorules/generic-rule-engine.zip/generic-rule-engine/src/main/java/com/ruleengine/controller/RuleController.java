package com.ruleengine.controller;

import com.ruleengine.model.*;
import com.ruleengine.service.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST API Controller for Rule Engine
 * Provides CRUD operations and rule execution endpoints
 */
@RestController
@RequestMapping("/api/rules")
@Tag(name = "Rule Engine API", description = "Generic Rule Engine with hot-reload from S3")
public class RuleController {

    private static final Logger log = LoggerFactory.getLogger(RuleController.class);

    private final RuleStorageService ruleStorageService;
    private final RuleExecutionService ruleExecutionService;

    public RuleController(RuleStorageService ruleStorageService,
                          RuleExecutionService ruleExecutionService) {
        this.ruleStorageService = ruleStorageService;
        this.ruleExecutionService = ruleExecutionService;

        // Initialize storage on startup
        ruleStorageService.initialize();
    }

    // ========================================================================
    // CRUD OPERATIONS
    // ========================================================================

    /**
     * Create or Update a rule
     */
    @PostMapping
    @Operation(summary = "Create or update a rule",
            description = "Uploads a rule to S3 and loads it into the engine")
    public ResponseEntity<RuleResponse> createOrUpdateRule(@Valid @RequestBody RuleRequest request) {
        try {
            log.info("Creating/updating rule: {}", request.getRuleId());

            RuleMetadata metadata = ruleStorageService.createOrUpdateRule(request);

            RuleResponse response = RuleResponse.success(
                    "Rule created/updated successfully: " + request.getRuleId());
            response.setMetadata(metadata);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Failed to create/update rule", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(RuleResponse.error("Failed to create/update rule", e.getMessage()));
        }
    }

    /**
     * Get rule metadata by ID
     */
    @GetMapping("/{ruleId}")
    @Operation(summary = "Get rule metadata",
            description = "Retrieve metadata for a specific rule")
    public ResponseEntity<RuleResponse> getRule(@PathVariable String ruleId) {
        try {
            log.info("Getting rule: {}", ruleId);

            RuleMetadata metadata = ruleStorageService.getRuleMetadata(ruleId);

            RuleResponse response = RuleResponse.success("Rule retrieved successfully");
            response.setMetadata(metadata);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Failed to get rule: {}", ruleId, e);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(RuleResponse.error("Rule not found", e.getMessage()));
        }
    }

    /**
     * List all rules
     */
    @GetMapping
    @Operation(summary = "List all rules",
            description = "Get a list of all rules stored in S3")
    public ResponseEntity<RuleResponse> listRules() {
        try {
            log.info("Listing all rules");

            List<RuleMetadata> rules = ruleStorageService.listAllRules();

            Map<String, Object> data = new HashMap<>();
            data.put("rules", rules);
            data.put("count", rules.size());

            RuleResponse response = RuleResponse.success("Rules retrieved successfully");
            response.setData(data);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Failed to list rules", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(RuleResponse.error("Failed to list rules", e.getMessage()));
        }
    }

    /**
     * Delete a rule
     */
    @DeleteMapping("/{ruleId}")
    @Operation(summary = "Delete a rule",
            description = "Delete a rule from S3 and remove from cache")
    public ResponseEntity<RuleResponse> deleteRule(@PathVariable String ruleId) {
        try {
            log.info("Deleting rule: {}", ruleId);

            ruleStorageService.deleteRule(ruleId);

            return ResponseEntity.ok(RuleResponse.success("Rule deleted successfully: " + ruleId));
        } catch (Exception e) {
            log.error("Failed to delete rule: {}", ruleId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(RuleResponse.error("Failed to delete rule", e.getMessage()));
        }
    }

    // ========================================================================
    // RULE EXECUTION
    // ========================================================================

    /**
     * Execute a rule with input data
     */
    @PostMapping("/{ruleId}/execute")
    @Operation(summary = "Execute a rule",
            description = "Execute a rule with provided input data")
    public ResponseEntity<RuleResponse> executeRule(
            @PathVariable String ruleId,
            @RequestBody Map<String, Object> inputData) {
        try {
            log.info("Executing rule: {} with input: {}", ruleId, inputData);

            Map<String, Object> result = ruleExecutionService.executeRule(ruleId, inputData);

            RuleResponse response = RuleResponse.success("Rule executed successfully");
            response.setResult(result);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Failed to execute rule: {}", ruleId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(RuleResponse.error("Failed to execute rule", e.getMessage()));
        }
    }

    /**
     * Execute a rule with trace information
     */
    @PostMapping("/{ruleId}/execute-with-trace")
    @Operation(summary = "Execute rule with trace",
            description = "Execute a rule and return detailed trace information")
    public ResponseEntity<RuleResponse> executeRuleWithTrace(
            @PathVariable String ruleId,
            @RequestBody Map<String, Object> inputData) {
        try {
            log.info("Executing rule with trace: {}", ruleId);

            Map<String, Object> result = ruleExecutionService.executeRuleWithTrace(ruleId, inputData);

            RuleResponse response = RuleResponse.success("Rule executed with trace successfully");
            response.setResult(result);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Failed to execute rule with trace: {}", ruleId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(RuleResponse.error("Failed to execute rule with trace", e.getMessage()));
        }
    }

    /**
     * Test a rule without saving it
     */
    @PostMapping("/test")
    @Operation(summary = "Test a rule",
            description = "Test a rule definition with input data without persisting it")
    public ResponseEntity<RuleResponse> testRule(@Valid @RequestBody TestRuleRequest request) {
        try {
            log.info("Testing rule: {}", request.getRuleId());

            // Get rule content from storage
            String ruleContent = ruleStorageService.getRuleContent(request.getRuleId());

            if (ruleContent == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(RuleResponse.error("Rule not found", "Rule ID: " + request.getRuleId()));
            }

            Map<String, Object> result = ruleExecutionService.testRule(ruleContent, request.getInputData());

            RuleResponse response = RuleResponse.success("Rule tested successfully");
            response.setResult(result);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Failed to test rule", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(RuleResponse.error("Failed to test rule", e.getMessage()));
        }
    }

    // ========================================================================
    // MANAGEMENT OPERATIONS
    // ========================================================================

    /**
     * Force reload all rules from S3
     */
    @PostMapping("/reload")
    @Operation(summary = "Reload all rules",
            description = "Force reload all rules from S3 into cache")
    public ResponseEntity<RuleResponse> reloadRules() {
        try {
            log.info("Force reloading all rules from S3");

            ruleStorageService.reloadAllRules();

            Map<String, Object> data = ruleStorageService.getCacheStats();

            RuleResponse response = RuleResponse.success("All rules reloaded successfully");
            response.setData(data);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Failed to reload rules", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(RuleResponse.error("Failed to reload rules", e.getMessage()));
        }
    }

    /**
     * Get cache statistics
     */
    @GetMapping("/stats")
    @Operation(summary = "Get cache statistics",
            description = "Get current cache statistics and configuration")
    public ResponseEntity<RuleResponse> getCacheStats() {
        try {
            Map<String, Object> stats = ruleStorageService.getCacheStats();

            RuleResponse response = RuleResponse.success("Cache statistics retrieved successfully");
            response.setData(stats);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Failed to get cache stats", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(RuleResponse.error("Failed to get cache stats", e.getMessage()));
        }
    }

    /**
     * Clear cache
     */
    @PostMapping("/cache/clear")
    @Operation(summary = "Clear cache",
            description = "Clear all cached rules (they will be reloaded on next access)")
    public ResponseEntity<RuleResponse> clearCache() {
        try {
            log.info("Clearing cache");

            ruleStorageService.clearCache();

            return ResponseEntity.ok(RuleResponse.success("Cache cleared successfully"));
        } catch (Exception e) {
            log.error("Failed to clear cache", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(RuleResponse.error("Failed to clear cache", e.getMessage()));
        }
    }

    /**
     * Health check
     */
    @GetMapping("/health")
    @Operation(summary = "Health check",
            description = "Check if the rule engine is healthy")
    public ResponseEntity<RuleResponse> healthCheck() {
        Map<String, Object> health = new HashMap<>();
        health.put("status", "UP");
        health.put("timestamp", java.time.LocalDateTime.now());
        health.put("cacheStats", ruleStorageService.getCacheStats());

        RuleResponse response = RuleResponse.success("Rule engine is healthy");
        response.setData(health);

        return ResponseEntity.ok(response);
    }
}