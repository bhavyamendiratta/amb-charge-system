curl -X POST http://localhost:8080/api/rules \
-H "Content-Type: application/json" \
-d '{
"ruleId": "amb-banking-rules",
"ruleName": "AMB Rules - Banking Average Monthly Balance",
"description": "Banking rules for Average Monthly Balance defaulter detection and charge calculation",
"active": true,
"ruleContent": {
"name": "AMB Rules - Banking Average Monthly Balance",
"contentType": "application/vnd.gorules.decision",
"nodes": [
{
"id": "input-1",
"name": "Input",
"type": "inputNode",
"position": {"x": 50, "y": 200},
"content": {
"fields": [
{"field": "checkDay", "name": "Check Day"},
{"field": "accountId", "name": "Account ID"},
{"field": "accountName", "name": "Account Name"},
{"field": "currentMonth", "name": "Current Month"},
{"field": "ambDay1To25", "name": "AMB Day 1-25"},
{"field": "ambDay1To30", "name": "AMB Day 1-30"},
{"field": "minBalance", "name": "Min Required Balance"},
{"field": "wasActualDefaulterLastMonth", "name": "Was Actual Defaulter Last Month"},
{"field": "wasProbableDefaulterLastMonth", "name": "Was Probable Defaulter Last Month"},
{"field": "actualDefaulterMonth1", "name": "Actual Defaulter Month-1"},
{"field": "actualDefaulterMonth2", "name": "Actual Defaulter Month-2"},
{"field": "shortfallMonth1", "name": "Shortfall Month-1"},
{"field": "shortfallMonth2", "name": "Shortfall Month-2"}
]
}
},
{
"id": "decision-table-1",
"name": "Probable Defaulter Rules (Day 25)",
"type": "decisionTableNode",
"position": {"x": 400, "y": 100},
"content": {
"hitPolicy": "first",
"inputs": [
{"id": "i1", "name": "Check Day", "field": "checkDay"},
{"id": "i2", "name": "AMB Day 1-25", "field": "ambDay1To25"},
{"id": "i3", "name": "Min Balance", "field": "minBalance"},
{"id": "i4", "name": "Was Actual Last Month", "field": "wasActualDefaulterLastMonth"}
],
"outputs": [
{"id": "o1", "name": "Action", "field": "probableDefaulterAction"},
{"id": "o2", "name": "Send SMS", "field": "sendSMS"},
{"id": "o3", "name": "Reason", "field": "probableDefaulterReason"}
],
"rules": [
{
"_id": "pd-1",
"_description": "Rule 1A: Probable Defaulter - Was Actual Last Month (No SMS)",
"i1": "checkDay == 25",
"i2": "ambDay1To25 < minBalance",
"i3": "",
"i4": "wasActualDefaulterLastMonth == true",
"o1": "\"MARK_PROBABLE_DEFAULTER\"",
"o2": "false",
"o3": "\"Was actual defaulter last month - NO SMS\""
},
{
"_id": "pd-2",
"_description": "Rule 1B: Probable Defaulter - New (Send SMS)",
"i1": "checkDay == 25",
"i2": "ambDay1To25 < minBalance",
"i3": "",
"i4": "wasActualDefaulterLastMonth == false",
"o1": "\"MARK_PROBABLE_DEFAULTER\"",
"o2": "true",
"o3": "\"New probable defaulter - SMS sent\""
}
]
}
},
{
"id": "decision-table-2",
"name": "Actual Defaulter Rules (Day 3)",
"type": "decisionTableNode",
"position": {"x": 400, "y": 300},
"content": {
"hitPolicy": "first",
"inputs": [
{"id": "i1", "name": "Check Day", "field": "checkDay"},
{"id": "i2", "name": "AMB Full Month", "field": "ambDay1To30"},
{"id": "i3", "name": "Min Balance", "field": "minBalance"},
{"id": "i4", "name": "Was Probable Last Month", "field": "wasProbableDefaulterLastMonth"}
],
"outputs": [
{"id": "o1", "name": "Action", "field": "actualDefaulterAction"},
{"id": "o2", "name": "Status", "field": "actualDefaulterStatus"}
],
"rules": [
{
"_id": "ad-1",
"_description": "Rule 2: Confirm Actual Defaulter",
"i1": "checkDay == 3",
"i2": "ambDay1To30 < minBalance",
"i3": "",
"i4": "wasProbableDefaulterLastMonth == true",
"o1": "\"MARK_ACTUAL_DEFAULTER\"",
"o2": "\"CONFIRMED_DEFAULTER\""
}
]
}
},
{
"id": "decision-table-3",
"name": "Charge Calculation Rules (Day 3)",
"type": "decisionTableNode",
"position": {"x": 400, "y": 500},
"content": {
"hitPolicy": "first",
"inputs": [
{"id": "i1", "name": "Check Day", "field": "checkDay"},
{"id": "i2", "name": "Defaulter Month-2", "field": "actualDefaulterMonth2"},
{"id": "i3", "name": "Defaulter Month-1", "field": "actualDefaulterMonth1"},
{"id": "i4", "name": "Shortfall Month-1", "field": "shortfallMonth1"},
{"id": "i5", "name": "Shortfall Month-2", "field": "shortfallMonth2"}
],
"outputs": [
{"id": "o1", "name": "Action", "field": "chargeAction"},
{"id": "o2", "name": "Charge Type", "field": "chargeType"}
],
"rules": [
{
"_id": "charge-1",
"_description": "Rule 3: Calculate Charge for 2 Consecutive Defaults",
"i1": "checkDay == 3",
"i2": "actualDefaulterMonth2 == true",
"i3": "actualDefaulterMonth1 == true",
"i4": "shortfallMonth1 > 0",
"i5": "shortfallMonth2 > 0",
"o1": "\"APPLY_CHARGE\"",
"o2": "\"TWO_MONTH_CONSECUTIVE\""
}
]
}
},
{
"id": "output-1",
"name": "Output",
"type": "outputNode",
"position": {"x": 800, "y": 300},
"content": {
"fields": [
{"field": "probableDefaulterAction", "name": "Probable Defaulter Action"},
{"field": "sendSMS", "name": "Send SMS"},
{"field": "probableDefaulterReason", "name": "Probable Defaulter Reason"},
{"field": "actualDefaulterAction", "name": "Actual Defaulter Action"},
{"field": "actualDefaulterStatus", "name": "Actual Defaulter Status"},
{"field": "chargeAction", "name": "Charge Action"},
{"field": "chargeType", "name": "Charge Type"}
]
}
}
],
"edges": [
{"id": "e1", "sourceId": "input-1", "targetId": "decision-table-1"},
{"id": "e2", "sourceId": "input-1", "targetId": "decision-table-2"},
{"id": "e3", "sourceId": "input-1", "targetId": "decision-table-3"},
{"id": "e4", "sourceId": "decision-table-1", "targetId": "output-1"},
{"id": "e5", "sourceId": "decision-table-2", "targetId": "output-1"},
{"id": "e6", "sourceId": "decision-table-3", "targetId": "output-1"}
]
}
}'





curl -X POST http://localhost:8080/api/rules/amb-banking-rules/execute \
-H "Content-Type: application/json" \
-d '{
"checkDay": 25,
"accountId": "ACC001",
"accountName": "John Doe",
"currentMonth": "2025-11",
"ambDay1To25": 8000,
"ambDay1To30": 0,
"minBalance": 10000,
"wasActualDefaulterLastMonth": false,
"wasProbableDefaulterLastMonth": false,
"actualDefaulterMonth1": false,
"actualDefaulterMonth2": false,
"shortfallMonth1": 0,
"shortfallMonth2": 0
}'


curl http://localhost:8080/api/rules/health

curl http://localhost:8080/api/rules
